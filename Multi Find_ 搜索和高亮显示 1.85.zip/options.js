//Multi Find, Vincent Greco, 2023-24
"use strict";

var DBG=false;

var hrefReview = "https://chromewebstore.google.com/detail/multi-find-search-and-hig/dffaiikpbncahnghlfnkhagffaemhgfo/reviews"; //Google Chrome
//var hrefReview = "https://microsoftedge.microsoft.com/addons/detail/multi-find-search-highl/kloenjeejidbakipjodcdmlajhnliapo"; //Microsoft Edge
//var hrefReview = "https://addons.mozilla.org/fr/firefox/addon/multi-find-search-highlight/"; //Mozilla Firefox

var options=[];
var optionsElement=[];
var colorsElement=[[],[]];
var colorsAddElement=[];
var colorsRemoveElement=[];
var nOptions=12;
var preview;
var display;
var search;
var display0, display2, display3, display4, display5, display6, display7;
var styleRegul, styleGlow, styleNone;
var search0;
var darkLight, darkSystem, darkDark;
var darkTheme = ['HL-light-theme', 'HL-system-theme', 'HL-dark-theme'];
var colorMax    = 20;
//var highlightColor;

document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("vers").textContent = "v"+ chrome.runtime.getManifest().version;
  preview=document.getElementById('preview');
  for(var i=0; i<nOptions; i++) {
    optionsElement[i]=document.getElementById("Option"+i.toString().padStart(2, "0"));
    optionsElement[i].addEventListener("change", optionsChange);
  }
  for(var i=0; i<colorMax; i++) {
    colorsElement[0][i]=document.getElementById("color0"+(i+"").padStart(2, '0'));
    colorsElement[0][i].addEventListener("change", colorsChange2);
    colorsElement[1][i]=document.getElementById("color1"+(i+"").padStart(2, '0'));
    colorsElement[1][i].addEventListener("change", colorsChange2);
  }
  for(var i=0; i<colorMax; i++) {
    colorsAddElement[i]=document.getElementById("addID"+(i+"").padStart(2, '0'));
    colorsAddElement[i].addEventListener("click", colorsAdd);
  }
  for(var i=0; i<colorMax; i++) {
    colorsRemoveElement[i]=document.getElementById("closeID"+(i+"").padStart(2, '0'));
    colorsRemoveElement[i].addEventListener("click", colorsRemove);
  }
  display0   = document.getElementById('display0');     display0.addEventListener("change", displayChange);
  styleRegul = document.getElementById('styleRegul'); styleRegul.addEventListener("change", displayChange);
  styleGlow  = document.getElementById('styleGlow');   styleGlow.addEventListener("change", displayChange);
  styleNone  = document.getElementById('styleNone');   styleNone.addEventListener("change", displayChange);
  display2   = document.getElementById('display2');     display2.addEventListener("change", displayChange);
  display3   = document.getElementById('display3');     display3.addEventListener("change", displayChange);
  display4   = document.getElementById('display4');     display4.addEventListener("change", displayChange);
  display5   = document.getElementById('display5');     display5.addEventListener("change", displayChange);
  display6   = document.getElementById('display6');     display6.addEventListener("change", displayChange);
  display7   = document.getElementById('display7');     display7.addEventListener("change", displayChange);
  search0    = document.getElementById('search0');       search0.addEventListener("change", searchChange);
  darkLight  = document.getElementById('darkLight');   darkLight.addEventListener("change", displayChange);
  darkSystem = document.getElementById('darkSystem'); darkSystem.addEventListener("change", displayChange);
  darkDark   = document.getElementById('darkDark');     darkDark.addEventListener("change", displayChange);
  document.getElementById('colorReset').addEventListener("click", setDefaultHighlightColors);
  //window.addEventListener("blur", closePopup);
  
  //window.addEventListener("focus", () => preview.contentWindow.location.reload()); // ???
  window.addEventListener("focus", updateInterface);
  
  updateInterface(); //loading local storage to popup window 
  
  localize();
  window.addEventListener('message', function (e) {
    // Get the sent data
    var message = e.data;
    if (message.action === "answerHeight") {  //preview
        preview.style.height=(message.height+1)+"px";
        preview.style.width=(message.width+1)+"px";
     }
    if (message.action=="requestTranparency") {
        if(message.value)
            preview.classList.add("HL-transparent");
        else
            preview.classList.remove("HL-transparent");

    }  
 });

}); 

function updateInterface()
{
  chrome.storage.local.get(["options", "display", "search"], function(result) {
    for(var i=0; i<nOptions; i++) {
      if(result.options && result.options[i]!==undefined) options[i]=optionsElement[i].checked=result.options[i]; else options[i]=optionsElement[i].checked=true;
    }
    
    display=result.display;
    if(result.display && result.display.scrollActive!==undefined) display0.checked=result.display.scrollActive; else display0.checked=true;
    if(result.display && result.display.scrollX!==undefined) display6.checked=result.display.scrollX; else display6.checked=true;
    if(result.display && result.display.style!==undefined) {
        switch(result.display.style)
        {
            case 0:  styleRegul.checked=true; break;
            case 1:  styleGlow.checked=true; break;
            case 2:  styleNone.checked=true; break;
            default: styleRegul.checked=true; break;
        }
    } else styleRegul.checked=true;
    if(result.display && result.display.counterOn!==undefined) display2.checked=result.display.counterOn; else display2.checked=true;
    if(result.display && result.display.persistentMenu!==undefined) display3.checked=result.display.persistentMenu; else display3.checked=true;
    if(result.display && result.display.transparentMenu!==undefined) display7.checked=result.display.transparentMenu; else display7.checked=false;
    if(result.display && result.display.persistentMenuX!==undefined) display4.checked=result.display.persistentMenuX; else display4.checked=true;
    if(result.display && result.display.persistentMenuY!==undefined) display5.checked=result.display.persistentMenuY; else display5.checked=true;
    if(result.display && result.display.darkMode!==undefined) {
      switch(result.display.darkMode){
        case 0: darkLight.checked  = true; break;
        case 1: darkSystem.checked = true; break;
        case 2: darkDark.checked   = true; break;
        default: darkSystem.checked = true; break;
      }
    } else darkSystem.checked=true; //default = system
    
    var darkMode=result?.display?.darkMode;
    //var colorOffset = result?.display?.colorOffset !== undefined ? result.display.colorOffset :  0;
    //var colorRange  = result?.display?.colorOffset !== undefined ? result.display.colorRange  : 10;    
    setAndReturnActualTheme(darkMode); //if darkMode is undefined, 1 is used in the function
    updateColorInterface2(display.highlightColor);
    
    search=result.search;
    if(result.search && result.search.oneChar!==undefined) search0.checked=result.search.oneChar; else search0.checked=false;
    optionSendMessageToPopup({action:"updatePopup", from:"option.js > updateInterface()"});
  });
}

function localize()
{
  var element = document.querySelectorAll("[data-content-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-content-loc"));
  	element[i].textContent=translation;
  }  
  var element = document.querySelectorAll("[data-title-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-title-loc"));
  	element[i].title=translation;
  }  
  
  var element = document.querySelectorAll("[data-lang-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-lang-loc"));
  	element[i].lang=translation;
  }  

  var element = document.querySelectorAll("[data-href-nav]");
  for(var i = 0; i < element.length; i++){
  	if (element[i].getAttribute("data-href-nav")=="html_review") element[i].href=hrefReview;
  }
  
  //modify textContent
  chrome.commands.getAll(function(commands) {
      var element = document.querySelectorAll("[data-shortcut-loc]");
      for(var i = 0; i < element.length; i++){
        const yourActionCommand = commands.find(command => command.name == element[i].getAttribute("data-shortcut-loc"));
        if(yourActionCommand?.shortcut) element[i].textContent=yourActionCommand.shortcut;
        else if(element[i].getAttribute("data-shortcut-loc")==="close") element[i].textContent="Esc";//hardcoded
      }
  });
}
/*
function changeThemes(darkMode)
{
    if(typeof(darkMode)=="undefined") darkMode=1;//default
    
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {     
      darkTheme[1]=darkTheme[2]; // browser is in dark mode
    } else {
      darkTheme[1]=darkTheme[0];
    }
    
    document.body.classList.remove(darkTheme[0]);
    document.body.classList.remove(darkTheme[2]);
    document.body.classList.add(darkTheme[darkMode]);
}
*/
function updateTheme()
{
  chrome.storage.local.get(["display"], function(result) {
    var tristateTheme=result?.display?.darkMode;
    setAndReturnActualTheme(tristateTheme);
  });
}

function setAndReturnActualTheme(tristateTheme) // 3 possible values (0=light, 1=system or 2=dark) + undefined
{
    if(tristateTheme===undefined) tristateTheme=1;//default=system
    
    //check system status
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {     
      darkTheme[1]=darkTheme[2]; // browser is in dark mode
    } else {
      darkTheme[1]=darkTheme[0];
    }
    
    //set theme
    document.body.classList.remove(darkTheme[0]);
    document.body.classList.remove(darkTheme[2]);
    document.body.classList.add(darkTheme[tristateTheme]);
    
    //compute actual theme 
    var actualTheme;
    if(tristateTheme==0) actualTheme=0;
    if(tristateTheme==2) actualTheme=1;
    if(tristateTheme==1) actualTheme= darkTheme[1]==darkTheme[2]?1:0;
    
    return actualTheme; // 2 possible values (0=light, 1=dark)
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateTheme);

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    //if(DBG) console.log("action:", message.action);
    if(message.action === "updateOptionsNew") {
        updateInterface();
    }
    if (message.action === "updateHighlightsAndPopup") {  //from background script
        updateInterface();
    }   
    sendResponse({received: "OK"}); 
});


function optionsChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> majChange>");
  options[+this.id.slice(-2)]=this.checked;

  //saving maj to local storage

  chrome.storage.local.set({options}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > optionsChange(e)"});
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > optionsChange(e)"});
  });
  //if(FF) preview.contentWindow.location.reload();

}

function updateColorInterface2(highlightColor)
{

  for(var i=0; i<colorMax; i++) {
    if(i<display.colorRange)
    {
        colorsElement[0][i].value=highlightColor[0][i].back;
        colorsElement[0][i].style.background=highlightColor[0][i].back;
        colorsElement[1][i].value=highlightColor[1][i].back;
        colorsElement[1][i].style.background=highlightColor[1][i].back;
        colorsElement[0][i].parentElement.style.display="flex";
    }
    else
    {
        colorsElement[0][i].parentElement.style.display="none";    
    }  
  }
}

function frontFromBack(color)
{
  var grey=(0.30*(+("0x"+color.slice(1,3)))+0.59*(+("0x"+color.slice(3,5)))+0.11*(+("0x"+color.slice(5,7))))|0;
  return (grey<128)?"white":"black"; 
}

function colorsChange2(e)
{
  
  //var theme=document.body.classList.contains(darkTheme[0])?0:1;
  var col=e.target.value;
  this.style.backgroundColor=col;
  display.highlightColor[+this.id.slice(-3,-2)][+this.id.slice(-2)].back=col;  
  display.highlightColor[+this.id.slice(-3,-2)][+this.id.slice(-2)].front=frontFromBack(col); //-2 to fix the bug of the 2nd half of the clors that cannot be modified
  
  //saving maj to local storage
  chrome.storage.local.set({display}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > colorsChange2(e)"});
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > colorsChange2(e)"});
  });
  //preview.contentWindow.location.reload();
}

function hue(color)
{
    var H
    var r=+("0x"+color.slice(1,3))/255;
    var g=+("0x"+color.slice(3,5))/255;
    var b=+("0x"+color.slice(5,7))/255;
    var cMax=Math.max(r,g,b);
    var cMin=Math.min(r,g,b);
    var delta=cMax-cMin
    if(delta==0) H=0;
    if(cMax==r) H=60*(((g-b)/delta+6)%6);
    if(cMax==g) H=60*((b-r)/delta+2);
    if(cMax==b) H=60*((r-g)/delta+4);
    if(H<0) console.log("error", H, color);
    return H;
}

function colorNew()
{
    var ret=[];
    for(var i=0; i<display.colorRange; i++)
    {
        ret.push({H0:hue(display.highlightColor[0][i].back)});
    }
    ret.sort((a,b)=>a.H0-b.H0);
    for(var i=0; i<ret.length; i++)
    {
        ret[i].H1=ret[(i+1)%ret.length].H0;
        if(ret[i].H0<ret[i].H1) ret[i].delta=ret[i].H1-ret[i].H0; else ret[i].delta=360+ret[i].H1-ret[i].H0; 
        if(ret[i].H0<ret[i].H1) ret[i].avg=Math.floor((ret[i].H0+ret[i].H1)/2); else ret[i].avg=Math.floor(180+(ret[i].H0+ret[i].H1)/2)%360; 
    }
    ret.sort((a,b)=>b.delta-a.delta);
    return ret[0].avg;
}

function colorsAdd(e)
{
  if(display.colorRange==colorMax) return;
  var H=colorNew();//Math.floor(Math.random()*360);
  var colNum=+this.id.slice(-2);
  for(var i=display.colorRange; i>colNum+1; i--)
  {
    display.highlightColor[0][i]={back:display.highlightColor[0][i-1].back, front:display.highlightColor[0][i-1].front};
    display.highlightColor[1][i]={back:display.highlightColor[1][i-1].back, front:display.highlightColor[1][i-1].front};
  }  
  var colLight=newColor(H, 1.0, 0.5);
  var colDark =newColor(H, 0.6, 0.3);
  display.highlightColor[0][colNum+1]={back:colLight, front:frontFromBack(colLight)};
  display.highlightColor[1][colNum+1]={back:colDark,  front:frontFromBack(colDark)};
  display.colorRange++;
  /*
  var theme;
  if(display.darkMode==0) theme=0;
  if(display.darkMode==2) theme=1;
  if(display.darkMode==1) theme= darkTheme[1]==darkTheme[2]?1:0;
    */
  updateColorInterface2(display.highlightColor);
  //saving updates to local storage
  chrome.storage.local.set({display}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > colorsAdd(e)"});
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > colorsAdd(e)"});
  });
  //preview.contentWindow.location.reload();
}

function colorsRemove(e)
{
  if(display.colorRange==1) return;
  var colNum=+this.id.slice(-2);
  for(var i=colNum; i<display.colorRange-1; i++)
  {
    display.highlightColor[0][i].back =display.highlightColor[0][i+1].back;
    display.highlightColor[0][i].front=display.highlightColor[0][i+1].front;
    display.highlightColor[1][i].back =display.highlightColor[1][i+1].back;
    display.highlightColor[1][i].front=display.highlightColor[1][i+1].front;
  }  
  display.colorRange--;  
  /*
  var theme;
  if(display.darkMode==0) theme=0;
  if(display.darkMode==2) theme=1;
  if(display.darkMode==1) theme= darkTheme[1]==darkTheme[2]?1:0;
  */
  updateColorInterface2(display.highlightColor);
  //saving maj to local storage
  chrome.storage.local.set({display}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from: "options.js > colorsRemove(e)"});
      optionSendMessageToPopup({action:"updatePopup", from: "options.js > colorsRemove(e)"});
  });
  //preview.contentWindow.location.reload();
}

function setDefaultHighlightColors()
{
  var s=getComputedStyle(document.documentElement);
  display.highlightColor=[[
    {back:s.getPropertyValue('--HL-high-light-0'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-1'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-2'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-3'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-4'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-5'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-6'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-7'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-8'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-9'), front:"black"}
  ],[
    {back:s.getPropertyValue('--HL-high-dark-0'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-1'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-2'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-3'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-4'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-5'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-6'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-7'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-8'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-9'), front:"white"}
  ]];
  display.colorRange=display.highlightColor[0].length;
  /*
  var theme;
  if(display.darkMode==0) theme=0;
  if(display.darkMode==2) theme=1;
  if(display.darkMode==1) theme= darkTheme[1]==darkTheme[2]?1:0;
  */
  updateColorInterface2(display.highlightColor);
  chrome.storage.local.set({display}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > setDefaultHighlightColors()"});
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > setDefaultHighlightColors()"});
  });
  //preview.contentWindow.location.reload();
  
}

function newColor(H, S, L)
{
    //With 0 <= H < 360, 0 <= S <= 1 and 0 <= L <= 1:
    var C = (1 - Math.abs(2*L - 1)) * S;
    var X = C * (1 - Math.abs((H / 60) % 2 - 1));
    var m = L - C/2;
    var col0;
    if(H>=  0 && H< 60) col0={r:C, g:X, b:0};
    if(H>= 60 && H<120) col0={r:X, g:C, b:0};
    if(H>=120 && H<180) col0={r:0, g:C, b:X};
    if(H>=180 && H<240) col0={r:0, g:X, b:C};
    if(H>=240 && H<300) col0={r:X, g:0, b:C};
    if(H>=300 && H<360) col0={r:C, g:0, b:X};
    
    var col={r:Math.floor((col0.r+m)*255), g:Math.floor((col0.g+m)*255), b:Math.floor((col0.b+m)*255)}
    return "#"+col.r.toString(16).padStart(2,'0')+col.g.toString(16).padStart(2,'0')+col.b.toString(16).padStart(2,'0');
}

function displayChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> majChange>");
  if(this.id==="display0") display.scrollActive=this.checked;
  if(this.id==="display6") display.scrollX=this.checked;
  //if(this.id==="display1") display.style=this.checked;
  if(this.id==="display2") display.counterOn=this.checked;
  if(this.id==="display3") {display.persistentMenu=this.checked; sendMessageToBackground("persistentMenuChange", this.checked);}
  if(this.id==="display7") {display.transparentMenu=this.checked; sendMessageToBackground("transparentMenuChange", this.checked);}
  if(this.id==="display4") display.persistentMenuX=this.checked;
  if(this.id==="display5") display.persistentMenuY=this.checked;
  if(this.id==="darkLight" || this.id==="darkSystem" || this.id==="darkDark")
  {
    if(!this.checked) return;
    if(this.id==="darkLight"  && this.checked) display.darkMode=0;  
    if(this.id==="darkSystem" && this.checked) display.darkMode=1;
    if(this.id==="darkDark"   && this.checked) display.darkMode=2; 
    setAndReturnActualTheme(display.darkMode);
    updateColorInterface2(display.highlightColor);
  } 
  if(this.id==="styleRegul" && this.checked) display.style=0;  
  if(this.id==="styleGlow"  && this.checked) display.style=1;
  if(this.id==="styleNone"  && this.checked) display.style=2; 

  //saving updates to local storage
  chrome.storage.local.set({display}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > displayChange(e)"}); //for every other windows
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > displayChange(e)"}); //for this window
  });
  //if(FF || this.id==="display1" || this.id==="darkLight" || this.id==="darkSystem" || this.id==="darkDark") preview.contentWindow.location.reload();
}

function searchChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> majChange>");
  if(this.id==="search0") search.oneChar=this.checked;

  //saving maj to local storage

  chrome.storage.local.set({search}).then(()=>{
      //if(DBG) console.log('Multi Find> majChange>maj=', maj);
      sendMessageToAllTabs({action:"updateOptionsNew", from:"options.js > searchChange(e)"});
      optionSendMessageToPopup({action:"updatePopup", from:"options.js > searchChange(e)"});
  });
  //if(FF) preview.contentWindow.location.reload();
}
/*
function sendMessage(action, param)
{
  //if(DBG) console.log("sendMessage", action);
  //chrome.tabs.query({currentWindow:true, active:true}, function (tabs){
  chrome.tabs.query({currentWindow:false, active:true}, function (tabs){
      var activeTab = tabs[0];
      chrome.tabs.sendMessage(activeTab.id, {action, param}, {}, function (response) {
          if (!chrome.runtime.lastError && response.received=="OK") {
            if(response.frameId) frameId=response.frameId;
            //if(DBG) console.log("Multi Find> sendMessage>response OK");
          } else {
//          if(DBG) console.log("Multi Find> sendMessage>no response", action);
          }
      });
  });
}
*/
function sendMessageToAllTabs(message)
{
  if(DBG) 
    console.log("sendMessageToAllTabs(",JSON.stringify(message),")");
  chrome.tabs.query({currentWindow:false, active:true}, function (tabs){
      //send to all frames of the active tab
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, message, function (response) {
          if(DBG) console.log("sw > sendMessageToTab (", message, ")");
          if (!chrome.runtime.lastError && response.received=="OK") {
            //if(response.frameId) frameId=response.frameId;
            //if(DBG) console.log("Multi Find> sendMessageToTab>response OK");
          } else {
//            if(DBG) console.log("Multi Find> sendMessageToTab>no response", message, selectedFrame);
          }
        });
      });
  });
}

function sendMessageToBackground(action, param)
{
  chrome.runtime.sendMessage({action, param}, {}, function (response) {
    if (!chrome.runtime.lastError && response.received=="OK") {

      //if(DBG) console.log("Multi Find> sendMessage>response OK");
    } else {
//    if(DBG) console.log("Multi Find> sendMessage>no response", action);
    }
  });
}

function optionSendMessageToPopup(message)
{
    preview.contentWindow.postMessage(message, "*");
}

