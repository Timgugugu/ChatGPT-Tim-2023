//Multi Find, Vincent Greco, 2023-24
"use strict";

var DBG=false;

var version = "1.85";
var firstTime;
var word;
var wordCount;
var wordOcc = -1, wordSelect = -1, globalOcc = -1;
var wordList;
var onBox;
//var clearID;
var loc;
var maj;
var diac;
var scrollActive;
var scrollX = true;
var majID;
var diacID;
var scrollID;
var themeMenu, themeID;
var unicode         = true;
var oneChar         = false;
var popupOn         = false;
var counterOn       = true;
var persistentMenu  = true;
var persistentMenuX = true;
var persistentMenuY = true;
var transparentMenu = false;
var darkMode=1;
//var unicodeID;
var loc0ID, loc1ID, loc2ID, loc3ID;
var tool0ID, tool1ID, tool2ID, tool3ID, tool4ID, tool5ID, tool6ID, tool7ID, tool8ID, tool0IDh;
var totalNumber;
var totalBtnPrev;
var totalBtnNext;

var highlightActive;
//var dbgID;
var optID;
var jumpID;
var jumpTotalID;
var closeID;
var helpID;
var optionsID;

var moveLeft, moveRight, moveTop, moveBottom, popupContainer;
var colorsElement=[];
var colorPicker;
var choosenCol;

var suppression = false;
var sel = {selBeg:{x:0, xMax:1, y:0, yMax:1, dx:0, dxMax:0}, selEnd:{x:0, xMax:1, y:0, yMax:1, dx:0, dxMax:0}};

var options = [];
var nOptions = 12;
var display0, display1, display2, display3a, display3b, display4, display5, display6, display7, display8, display9, display9bis, display10;
//var activeTab = null;

var highlightStyle = 0; //default = regular
//var tagStyle = 'HL-shadow-'; //default
var tagRound = 'HL-round-'; 
var darkTheme = ['HL-light-theme', 'HL-system-theme', 'HL-dark-theme'];
var menuThemeString = ['\u263c', '\u25d0', '\u263e'];
var colorOffset =  0;
var colorRange  = 10;
var colorMax    = 20;
var orSeparator = "|";

var highlightColor;
var theme=0;


//const charUp=   "<img src='./images/charUp-160.png' class='icon'>";//"&#x2190;"; //"&#x25B3;"; //"&#x27E8;";
//const charDown= "<img src='./images/charDown-160.png' class='icon'>";//"&#x2192;"; //"&#x25BD;"; //"&#x27E9;";
const charUp   = "./images/charUp-160.png";
const charDown = "./images/charDown-160.png";
const charOn =   "./images/charOn-160.png";//to be changed
const charOff  = "./images/charOff-160.png";//to be changed

var oldText;
var doAction=[];
var doIndex=0;
var doActionSizeMax=100000;

function load_132()
{
  //loading local storage to popup window
  chrome.storage.local.get(["word", "sel", "highlightActive", "maj", "diac", "scrollActive", "unicode", "loc"], function(result) {
  //if(DBG) console.log(result)     ;
      var toBeUpdated=false;

      word = result.word;
      if(!word) {word=[{text:"", on:true, colIndex:0}]; toBeUpdated=true;}
      if(typeof word[0] == "string") {for(let i=0; i<word.length; i++) word[i]={text:word[i], on:true, colIndex:i}; toBeUpdated=true;}
      if(firstTime) wordCount=new Array(word.length).fill(0);
      firstTime=false; //we do not need firsTime anymore

      oldText=word.map(a=>a.text).join('\n');

      if(result?.sel?.selBeg && result?.sel?.selEnd) sel=result.sel; else toBeUpdated=true;//keep the default value and save it

      highlightActive=result.highlightActive; if(highlightActive===undefined) {highlightActive=true; toBeUpdated=true;}
      onBox.checked=highlightActive;
      
      highlightColor=setDefaultHighlightColors();

      maj=result.maj;
      if(maj===undefined) {maj=false; toBeUpdated=true;}
      majID.checked=maj;

      diac=result.diac;
      if(diac===undefined) {diac=true; toBeUpdated=true;}   //default it true!
      diacID.checked=diac;

      scrollActive=result.scrollActive;
      if(scrollActive===undefined) {scrollActive=false; toBeUpdated=true;}
      scrollID.checked=scrollActive;

      counterOn=true; //new
      persistentMenu=true;
      transparentMenu=false;
      
      darkMode=1;
      themeID.textContent = menuThemeString[darkMode];
      theme=setAndReturnActualTheme(darkMode); 

      colorOffset =  0;
      colorRange  = 10;
      
      unicode=result.unicode;
      if(unicode===undefined) {unicode=true; toBeUpdated=true;}//default is now true!!!
      //unicodeID.checked=unicode;

      loc=result.loc;
      if(loc===undefined) {loc=0; toBeUpdated=true;}
      loc0ID.classList.remove("pushed"); loc1ID.classList.remove("pushed"); loc2ID.classList.remove("pushed"); loc3ID.classList.remove("pushed");
      if(loc==0) loc0ID.classList.add("pushed");
      if(loc==1) loc1ID.classList.add("pushed");
      if(loc==2) loc2ID.classList.add("pushed");
      if(loc==3) loc3ID.classList.add("pushed");
      
      oneChar = false; //new
      
      highlightStyle=0;
//      tagStyle='HL-shadow-'; //new
      
      popupOn=true; //new
         
      chrome.storage.local.clear(function() {
      allChange();//the version of the local storage was outdated: update it in any case.
      options=[]; for(var i=0; i<nOptions; i++) options[i]=true;
      updateDisplayWithOptions();
      updateWordListDisplay("from load 1.32"); //useful if no answer is sent from previous line (page to be refreshed)
     
      //sendMessage({action:"requestWordCount", from:"load_132()"}); //to be removed?
      //sendMessage({action:"confirmOpenPopup", height:document.body.offsetHeight, from:"load_132()"}); //to be removed?

      });
  });
}
function setDefaultHighlightColors()
{
  var s=getComputedStyle(document.documentElement);
  var ret=[[
    {back:s.getPropertyValue('--HL-high-light-0'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-1'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-2'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-3'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-4'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-5'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-6'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-7'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-8'), front:"black"},
    {back:s.getPropertyValue('--HL-high-light-9'), front:"black"}
  ],[
    {back:s.getPropertyValue('--HL-high-dark-0'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-1'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-2'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-3'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-4'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-5'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-6'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-7'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-8'), front:"white"},
    {back:s.getPropertyValue('--HL-high-dark-9'), front:"white"}
   ]];
  return ret;
}
var done;
function load_133()
{
  //loading local storage to popup window
  chrome.storage.local.get(["page", "display", "search", "options"], function(result) {
    if(DBG) console.log("load 1.33 begin");
    if(DBG) console.log(result); ///
    if (!chrome.runtime.lastError) {
      var toBeUpdated=false;
      
      if(result?.page?.doAction)
      {
        doAction = result.page.doAction;
        if(result?.page?.doIndex)  doIndex  = result.page.doIndex;  else doIndex=doAction.length;
        if(doIndex>doAction.length) doIndex=doAction.length
        //if(doIndex>0) word=doAction[doIndex-1].newText.split('\n'); else word=[];
      }
      else toBeUpdated=true;
      
      if(doIndex===doAction.length) tool7ID.classList.add("disabled"); else tool7ID.classList.remove("disabled");   
      if(doIndex===0) tool6ID.classList.add("disabled"); else tool6ID.classList.remove("disabled");   

      word = result?.page?.word;
      //if(!word) {word=[]; toBeUpdated=true;}
      if(!word) {word=[{text:"", on:true, colIndex:0}]; toBeUpdated=true;}
      if(typeof word[0] == "string") {for(let i=0; i<word.length; i++) word[i]={text:word[i], on:true, colIndex:i}; toBeUpdated=true;}
  
      if(firstTime) wordCount=new Array(word.length).fill(0);//to be updated.
      oldText=word.map(a=>a.text).join('\n');
      
      //if(result?.page?.sel) selMem=result.page.sel;
      //if(result?.page?.sel?.selBeg && result?.page?.sel?.selEnd) sel=result.page.sel; else toBeUpdated=true;//keep the default value and save it
      
      highlightActive=result?.display?.highlightActive;
      if(highlightActive===undefined) {highlightActive=true; toBeUpdated=true;}
      onBox.checked=highlightActive;
      
      highlightColor=result?.display?.highlightColor;
      if(highlightColor===undefined) {highlightColor=setDefaultHighlightColors(); toBeUpdated=true;}
      
      
      maj=result?.search?.maj;
      if(maj===undefined) {maj=false; toBeUpdated=true;}
      majID.checked=maj;
      
      diac=result?.search?.diac;
      if(diac===undefined) {diac=true; toBeUpdated=true;}   //default it true!
      diacID.checked=diac;
      
      scrollActive=result?.display?.scrollActive;
      if(scrollActive===undefined) {scrollActive=false; toBeUpdated=true;}
      scrollID.checked=scrollActive;
      scrollX=result?.display?.scrollX;
      if(scrollX===undefined) {scrollX=true; toBeUpdated=true;}
      if(scrollX) sendMessage({action:"moveScroll", dir:"right"}); else sendMessage({action:"moveScroll", dir:"left"});
  
      
      counterOn=result?.display?.counterOn;
      if(counterOn===undefined) {counterOn=true; toBeUpdated=true;}
      
      persistentMenu=result?.display?.persistentMenu;
      if(persistentMenu===undefined) {persistentMenu=true; toBeUpdated=true;}
      if(firstTime)
      {
        persistentMenuX=result?.display?.persistentMenuX;
        if(persistentMenuX===undefined) {persistentMenuX=true; toBeUpdated=true;}
        persistentMenuY=result?.display?.persistentMenuY;
        if(persistentMenuY===undefined) {persistentMenuY=true; toBeUpdated=true;}
        if(persistentMenuX) moveSearchWindow.bind(moveRight)(); else moveSearchWindow.bind(moveLeft)();
        if(persistentMenuY) moveSearchWindow.bind(moveTop)(); else moveSearchWindow.bind(moveBottom)();
      }

      transparentMenu=result?.display?.transparentMenu;
      if(transparentMenu===undefined) {transparentMenu=false; toBeUpdated=true;}
      //if(firstTime)
      {
        sendMessage({action:"requestTranparency", value:transparentMenu, from:"popup.js > load_133()"});   
      }
      firstTime=false; //we do not need firsTime anymore
      darkMode=result?.display?.darkMode;
      if(darkMode===undefined) {darkMode=1; toBeUpdated=true;}
      themeID.textContent = menuThemeString[darkMode];
      
      theme=setAndReturnActualTheme(darkMode); 
      /*
      if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {     
        darkTheme[1]=darkTheme[2]; // browser is in dark mode
      } else {
        darkTheme[1]=darkTheme[0];
      }
      if(darkMode==0) theme=0;
      if(darkMode==2) theme=1;
      if(darkMode==1) theme= darkTheme[1]==darkTheme[2]?1:0;
      
      
      document.body.classList.remove(darkTheme[0]);
      document.body.classList.remove(darkTheme[2]);
      document.body.classList.add(darkTheme[darkMode]);
      */
      colorOffset = result?.display?.colorOffset !== undefined ? result.display.colorOffset :  0;
      colorRange  = result?.display?.colorRange  !== undefined ? result.display.colorRange  : 10;
      
      for(var i=0;i<word.length; i++) if(word[i].colIndex<colorOffset || word[i].colIndex>=colorOffset+colorRange) {word[i].colIndex=(word[i].colIndex+colorRange*100-colorOffset)%colorRange+colorOffset; toBeUpdated=true;}
      
      colorPickerHeightOpen=1+32*Math.floor((colorRange-1)/10+1)+"px";
      if(colorPicker.style.height!=colorPickerHeightClosed && colorPicker.style.height!="") colorPicker.style.height=colorPickerHeightOpen;//update if already opened
      unicode=result?.search?.unicode;
      if(unicode===undefined) {unicode=true; toBeUpdated=true;}//default is now true!!!
      //unicodeID.checked=unicode;
      
      loc=result?.search?.loc;
      if(loc===undefined) {loc=0; toBeUpdated=true;}
      loc0ID.classList.remove("pushed"); loc1ID.classList.remove("pushed"); loc2ID.classList.remove("pushed"); loc3ID.classList.remove("pushed");
      if(loc==0) loc0ID.classList.add("pushed");
      if(loc==1) loc1ID.classList.add("pushed");
      if(loc==2) loc2ID.classList.add("pushed");
      if(loc==3) loc3ID.classList.add("pushed");
      
      oneChar=result?.search?.oneChar;
      if(oneChar===undefined) {oneChar=false; toBeUpdated=true;}
      
//      tagStyle=result?.display?.style?'HL-glow-':'HL-shadow-';
      highlightStyle=result?.display?.style;
      if(highlightStyle===undefined) {highlightStyle=0; toBeUpdated=true;}// default = regular
      if(highlightStyle===false)     {highlightStyle=0; toBeUpdated=true;}// regular
      if(highlightStyle===true)      {highlightStyle=1; toBeUpdated=true;}// glow
      
      if(result?.display?.popupOn===undefined || result?.display?.popupOn===false) toBeUpdated=true;
      popupOn=true;
      
      if(toBeUpdated) allChange(); //a field was missing in the local storage: update it.
      
      updateColorPicker(theme);
      if(!result.options) {options=[]; for(var i=0; i<nOptions; i++) options[i]=true;}
      else
      for(var i=0; i<nOptions; i++) {
        if(result.options[i]!==undefined) options[i]=result.options[i]; else options[i]=true;
      }

      updateDisplayWithOptions();
      updateWordListDisplay("from load 1.33"); //useful if no answer is sent from previous line (page to be refreshed)
     
      //sendMessage({action:"requestWordCount", from:"load_133()"}); //to be removed?
      //sendMessage({action:"confirmOpenPopup", height:document.body.offsetHeight, from:"load_133()"}); //to be removed?
      //requestAnimationFrame(function() {
          sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
      //});
      if(DBG) console.log("load 1.33 end");
    } else {
      if(DBG) console.log("ERROR on chrome.storage.local.get (load_133)", chrome.runtime.lastError);
    }
    
  });
}

function updateTheme()
{
  chrome.storage.local.get(["display"], function(result) {
    var tristateTheme=result?.display?.darkMode;
    setAndReturnActualTheme(tristateTheme);
  });
}

function updateThemeFromMenu()
{
    var tristateTheme=+this.dataset.value;
    setAndReturnActualTheme(tristateTheme);
    themeID.textContent = menuThemeString[tristateTheme]; // this.textContent;
    themeMenu.style.display = 'none'; // Hide menu after selection

    darkMode=tristateTheme;
    //saving updates to local storage
    chrome.storage.local.set({display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}}).then(()=>{
        //if(DBG) console.log('Multi Find> majChange>maj=', maj);
        sendMessage2({action:"updateOtherWindows", from:"popup.js > updateThemeFromMenu()"});
        //optionSendMessageToPopup({action:"updatePopup", from:"options.js > displayChange(e)"});
    });

}

function setAndReturnActualTheme(tristateTheme) // 3 possible values (0=light, 1=system or 2=dark) + undefined
{
    if(tristateTheme===undefined) tristateTheme=1;//default=system
    
    //check system status
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {     
      darkTheme[1]=darkTheme[2]; // browser is in dark mode
    } else {
      darkTheme[1]=darkTheme[0];
    }
    
    //set theme
    document.body.classList.remove(darkTheme[0]);
    document.body.classList.remove(darkTheme[2]);
    document.body.classList.add(darkTheme[tristateTheme]);
    
    //compute actual theme 
    var actualTheme;
    if(tristateTheme==0) actualTheme=0;
    if(tristateTheme==2) actualTheme=1;
    if(tristateTheme==1) actualTheme= darkTheme[1]==darkTheme[2]?1:0;
    
    return actualTheme;
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateTheme);

document.addEventListener("DOMContentLoaded", function() {
    if(DBG) console.log("DOMContentLoaded begin");

    wordList=document.getElementById("wordsID");  wordList.addEventListener("input", textareaChangeAndRecord);
    onBox=document.getElementById("onID");        onBox.addEventListener("change", checkboxChange);
    themeMenu=document.getElementById("themeMenu");
    themeID=document.getElementById("themeID");        themeID.addEventListener("click", () => {themeMenu.style.display = themeMenu.style.display === 'block' ? 'none' : 'block';});
    //themeID=document.getElementById("themeID");        themeID.addEventListener("click", menuClick);
    document.querySelectorAll('#themeMenu li').forEach(item => {
        item.addEventListener('click', updateThemeFromMenu);
    });
    //clearID=document.getElementById("clearID");   clearID.addEventListener("click", clearChange);
    loc0ID=document.getElementById("loc0ID");     loc0ID.addEventListener("click", locChange);
    loc1ID=document.getElementById("loc1ID");     loc1ID.addEventListener("click", locChange);
    loc2ID=document.getElementById("loc2ID");     loc2ID.addEventListener("click", locChange);
    loc3ID=document.getElementById("loc3ID");     loc3ID.addEventListener("click", locChange);
    
    tool0ID=document.getElementById("tool0ID");   if(!tool0ID.classList.contains("disabled")) tool0ID.addEventListener("click", ()=>{fileFinder=true;});
    tool0IDh=document.getElementById("tool0IDh"); if(!tool0ID.classList.contains("disabled")) tool0IDh.addEventListener("change", toolLoad); else tool0IDh.disabled=true;
    tool1ID=document.getElementById("tool1ID");   if(!tool1ID.classList.contains("disabled"))  tool1ID.addEventListener("click",  toolSave);
    tool2ID=document.getElementById("tool2ID");   tool2ID.addEventListener("click", toolClearAll);
    tool3ID=document.getElementById("tool3ID");   tool3ID.addEventListener("click", toolClearNotFound);
    tool4ID=document.getElementById("tool4ID");   tool4ID.addEventListener("click", toolClearFound);
    tool5ID=document.getElementById("tool5ID");   tool5ID.addEventListener("click", toolSortAlpha);
    tool8ID=document.getElementById("tool8ID");   tool8ID.addEventListener("click", toolSortFreq);
    tool6ID=document.getElementById("tool6ID");   tool6ID.addEventListener("click", toolUndo);
    tool7ID=document.getElementById("tool7ID");   tool7ID.addEventListener("click", toolRedo);
    
    totalNumber=document.getElementById("total-number"); 
    totalBtnPrev=document.getElementById("total-btn-prev");  totalBtnPrev.onclick=jumpUp;
    totalBtnNext=document.getElementById("total-btn-next");  totalBtnNext.onclick=jumpDown;


    majID=document.getElementById("majID");       majID.addEventListener("click", majChange);
    diacID=document.getElementById("diacID");     diacID.addEventListener("click", diacChange);
    scrollID=document.getElementById("scrollID"); scrollID.addEventListener("click", scrollChange);
    document.getElementById("vers").textContent = "v"+ chrome.runtime.getManifest().version;
    closeID=document.getElementById("closeID");  closeID.addEventListener("click", closePopup);
    helpID=document.getElementById("helpID");    helpID.addEventListener("click", ()=>window.open(chrome.i18n.getMessage("fil_welcome")));
    //optionsID=document.getElementById("optionsID");  optionsID.addEventListener("click", ()=>{chrome.runtime.openOptionsPage();});
    optionsID=document.getElementById("optionsID");  optionsID.addEventListener("click", ()=>window.open("options.html"));
    //unicodeID=document.getElementById("unicodeID");      unicodeID.addEventListener("click", uniChange);
    //dbgID=document.getElementById("dbgID");
    jumpID=document.getElementById("jump-container");
    optID=document.getElementById("options-container");
    jumpTotalID=document.getElementById("jump-total-container");
    
    display0=document.getElementById("display0");
    display1=document.getElementById("display1");
    display2=document.getElementById("display2");
    display3a=document.getElementById("jump-container");
    display3b=document.getElementById("display3b");
    display4=document.getElementById("display4");
    display5=document.getElementById("display5");
    display6=document.getElementById("display6");
    display7=document.getElementById("display7");
    display8=document.getElementById("display8");
    display9=document.getElementById("display9");
    display9bis=document.getElementById("options-container");
    display10=document.getElementById("display10");
    
    
    for(let c=0; c<colorMax; c++)
    {
        colorsElement[c]=document.getElementById("color"+(""+c).padStart(2,'0')+"_ID");
        colorsElement[c].onclick=pickNewColor;
    }
    colorPicker = document.getElementById("color-picker");  
  
    moveLeft=document.getElementById(  "move-left");      moveLeft.addEventListener(   "click", moveSearchWindow);  
    moveRight=document.getElementById( "move-right");     moveRight.addEventListener(  "click", moveSearchWindow); moveRight.style.display="none";
    moveTop=document.getElementById(   "move-top");       moveTop.addEventListener(    "click", moveSearchWindow); moveTop.style.display="none";
    moveBottom=document.getElementById("move-bottom");    moveBottom.addEventListener( "click", moveSearchWindow); 
    popupContainer=document.getElementById("popup-container");   

  // Search for data and translate it to current use language
  var element = document.querySelectorAll("[data-content-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-content-loc"));
  	element[i].textContent=translation;
  }  

  var element = document.querySelectorAll("[data-title-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-title-loc"));
  	element[i].title=translation;
  }  

  var element = document.querySelectorAll("[data-lang-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-lang-loc"));
  	element[i].lang=translation;
  }  

    document.addEventListener("selectionchange", selectionChange);
    window.addEventListener("blur", blurPopup);
    window.addEventListener("focus", focusPopup);
      
    wordList.addEventListener("paste", function(e) {
        // cancel paste
        e.preventDefault();
        // get text representation of clipboard
        var text = (e.originalEvent || e).clipboardData.getData('text/plain');
        // insert text manually
        document.execCommand("insertHTML", false, text);
    });
    document.addEventListener('keydown', (e) => {
    //if(DBG) console.log(e, e.keyCode);
      if(e.keyCode==27) closePopup();

    });   

    
    wordList.addEventListener('keydown', (e) => {
    //if(DBG) console.log(e, e.keyCode);

      suppression=false;
      if(e.keyCode==46) suppression=true; // del
      if(e.keyCode==8 && sel.selBeg.x==0 && sel.selBeg.dx==0 && sel.selBeg.y>0)
      {
        /*
        console.log("before ", JSON.stringify(sel));
        sel.selEnd.y--;
        sel.selEnd.yMax--;
        sel.selEnd.x=wordList.children[sel.selEnd.y].children.length-1;
        sel.selEnd.xMax=wordList.children[sel.selEnd.y].children.length+wordList.children[sel.selEnd.y+1].children.length-1;
        sel.selEnd.dx=wordList.children[sel.selEnd.y].children[sel.selEnd.x].textContent.length;
        sel.selEnd.dxMax=sel.selEnd.dx=sel.selEnd.dx+wordList.children[sel.selEnd.y+1].children[0].textContent.length;
        
        sel.selBeg.y=sel.selEnd.y;
        sel.selBeg.x=sel.selEnd.x;
        sel.selBeg.dx=sel.selEnd.dx;
        sel.selBeg.yMax=sel.selEnd.yMax;
        sel.selBeg.xMax=sel.selEnd.xMax;
        sel.selBeg.dxMax=sel.selEnd.dxMax;
        //suppression=true; // BS at the beginning of a line
        console.log("after  ", JSON.stringify(sel));
        */
      }

      if(e.keyCode==40 && sel.selBeg.y===sel.selBeg.yMax-1)                     // key down at the last line
      {
            //word.push({text:"", on:true, colIndex:(word.length%colorRange+colorOffset)%colorMax});      
            word.push({text:"", on:true, colIndex:(wordList.childElementCount%colorRange+colorOffset)%colorMax});      
            //textareaChangeAndRecord();     
            doRecord(word.map(a=>a.text).join('\n'));       
      }
      if(e.keyCode==90 && e.ctrlKey) {e.preventDefault(); toolUndo();}   //Ctrl+Z
      if(e.keyCode==89 && e.ctrlKey) {e.preventDefault(); toolRedo();}   //Ctrl+Y
      if (DBG) if(e.keyCode==88 && e.ctrlKey) {doAction=[]; doIndex=0;};   //Ctrl+X // debug

      //dbgID.innerHTML+=" "+e.keyCode;
    });   


    firstTime=true;

    //loading local storage to popup window
    chrome.storage.local.get(["version"], function(result) {
      if(DBG) console.log("version", result.version);
      if(!result.version || result.version<="1.32") load_132();
      if(result.version>="1.33") load_133();
    });

    chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
        handleMessagePopup(message, sender),
        sendResponse({received: "OK"}); 
    });
/**/
    if(DBG) console.log("DOMContentLoaded end");
});

window.addEventListener("message", function (e) {
    // Get the sent data
    var message = e.data;
    handleMessagePopup(message, null);
});

function handleMessagePopup(message, sender)
{
        if(message.action=="askForFocus" || message.action=="updateBadge" || message.action=="updateHighlightsAndPopup" || message.action=="updateOtherWindows") return;//this message is for sw.js; not for popup.js
        //if(DBG)
        //console.log("rcvd before msg: message:", JSON.stringify(message), "sender.tab.id:", sender?.tab?.id);
        if(message.action=="updatePopup")
        {
            if(typeof(message.wordCount)  != "undefined") wordCount  = message.wordCount;
            load_133();
        }
//        if(activeTab && sender && sender.tab && sender.tab.id!==activeTab.id) return;
        if(message.action=="updateWordCount") {    //sender should always be the active frame
            if(typeof(message.wordCount)  != "undefined") wordCount  = message.wordCount;
            if(typeof(message.wordSelect) != "undefined") wordSelect = message.wordSelect;
            if(typeof(message.wordOcc)    != "undefined") wordOcc    = message.wordOcc;
            if(typeof(message.globalOcc)  != "undefined") globalOcc  = message.globalOcc;
            //if(typeof(message.word)       != "undefined") word       = message.word;
            updateWordListDisplay("message updateWordCount");
        }
        if(message.action=="updateWordList") {    //sender should always be the active frame
            word = message.word;
            wordList.textContent = word.map(a=>a.text).join('\n');
            textareaChangeAndRecord("handleMessagePopup()");
        }
        //if(message.action=="updatePopup") load_133(); //moved 11 lines higher
        if(message.action=="updateHighlight") {highlightActive=message.highlightActive; onBox.checked=highlightActive; updateWordListDisplay("updateHighlight");}
        if(message.action=="toggleHighlight") {onBox.checked=!onBox.checked; highlightActive=onBox.checked; updateWordListDisplay("toggleHighlight");checkboxChange();}
        if(message.action=="askForHeight") {
                //document.body.height=document.body.scrollHeight
                //document.body.width=document.body.scrollWidth
                //if(document.body.scrollHeight>document.body.clientHeight) document.body.style.height=+"px"
                //if(document.body.scrollHeight==document.body.clientHeight) document.body.style.height="100%";

                //setTimeout(function() {
                    sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
                //}, 50);
        }
        if(message.action=="webpageResize") {
                var answer=false;
                if(message.width<popupContainer.style.width || message.height<popupContainer.style.height) answer=true;
                popupContainer.style.maxWidth=message.width+"px";
                popupContainer.style.maxHeight=message.height+"px";
                if(answer)
                    //requestAnimationFrame(function() {
                        sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
                    //});
        }

}
 
function updateDisplayWithOptions()
{
  //chrome.storage.local.get(["options"], function(result) {
  //  if(!result.options) {options=[]; for(var i=0; i<nOptions; i++) options[i]=true;}
  //  else
  //  for(var i=0; i<nOptions; i++) {
  //    if(result.options[i]!==undefined) options[i]=result.options[i]; else options[i]=true;
  //  }
     display0.style.display=options[0]?"flex":"none"; 
     display1.style.display=options[1]?"block":"none"; 
     display2.style.display=options[2]?"block":"none"; 
    display3a.style.display=options[3]?"block":"none"; 
    display3b.style.display=options[3]?"flex":"none"; 
     display4.style.display=options[4]?"flex" :"none"; 
     display5.style.display=options[5]?"flex" :"none"; 
     display6.style.display=options[6]?"flex" :"none"; 
     display7.style.display=options[7]?"block":"none"; 
     display8.style.display=options[8]?"flex" :"none"; 
     display9.style.display=options[9]?"flex" :"none"; 
    display9bis.style.display=options[10]?"inline-block":"none"; 
    display10.style.display=options[11]?"block":"none"; 
  //}); 
}

function initWordTemplate()
{
    var div = document.createElement("div");
    var span = document.createElement("span");
    div.appendChild(span); 
    var text = document.createTextNode("");
    span.appendChild(text); 
    return div;
}
var wordTemplate=initWordTemplate();

function initJumpTemplate()
{
    var div = document.createElement("div");  div.classList.add("right-containers");
    var span = document.createElement("span");

    var bUp   = document.createElement("button");
    var bUpImg = document.createElement("img");
    bUpImg.classList.add("icon");
    bUpImg.src = charUp;
    bUp.appendChild(bUpImg);
//    bUp.onclick=jumpUp;
    
    var bDown = document.createElement("button");
    var bDownImg = document.createElement("img");
    bDownImg.classList.add("icon");
    bDownImg.src = charDown;
    bDown.appendChild(bDownImg);
//    bDown.onclick=jumpDown;

    
    var text = document.createTextNode("-");
    div.appendChild(span);
    span.appendChild(text)
        
    div.appendChild(bUp); 
    div.appendChild(bDown);
    
    return div;
}
var jumpTemplate=initJumpTemplate();

function initOptTemplate()
{
    var div = document.createElement("div");  div.classList.add("right-containers");
    var bVisibleLbl = document.createElement("label");
    var bVisible   = document.createElement("input"); bVisible.type = 'checkbox';
    var bVisibleSpan = document.createElement("span");
    bVisibleLbl.classList="toggle-button";
    bVisibleSpan.classList="fakeButton";
    //bVisible.checked=word[i].on;
    bVisibleLbl.appendChild(bVisible);
    bVisibleLbl.appendChild(bVisibleSpan);
    //bVisible.setAttribute("HL-word", i);
    //bVisible.onclick=changeVisible;
    div.appendChild(bVisibleLbl); 

    var bColor   = document.createElement("button");
    var bColorSpan = document.createElement("span");
    bColorSpan.appendChild(document.createTextNode("\u00A0"))
    //bColor.style.backgroundColor=highlightColor[theme][word[i].colIndex].back;
    //bColor.setAttribute("HL-word", i);
    //bColor.onclick=chooseColorToBeChanged;
    bColor.appendChild(bColorSpan);
    div.appendChild(bColor); 

    div.appendChild(document.createTextNode("\u00A0"));//to have the correct height

    return div;
}
var optTemplate=initOptTemplate();

function setHighlightStyle(span, col)
{
    span.style.backgroundColor=highlightColor[theme][col].back;
    span.style.color=highlightColor[theme][col].front;
    if(highlightStyle===1) span.style.boxShadow= "0 0 0.5em 0.1em "+highlightColor[theme][col].back+", 0.1em 0.2em 0.2em 0em #0004";
}
function unsetHighlightStyle(span)
{
    span.style.backgroundColor="inherit";
    span.style.color="inherit";
    span.style.boxShadow= "unset";
}

function updateWordListDisplay(from)
{
    var t0, t1; //DGB only
    if(DBG) t0=Date.now();
    if(DBG) console.log("updateWordListDisplay from", from, word, wordCount);
    if (word)
    {
        var nxt;
        for(var elmt=wordList.firstChild; elmt!=null; elmt=nxt) {nxt=elmt.nextSibling; if(elmt.nodeName=="#text") wordList.removeChild(elmt);}
        
        // Populate form fields with saved data
        var tempWordList = document.createDocumentFragment();
        for(var i=0; i<word.length; i++)
        {
            var col = word[i].colIndex;
            
            var div;
            if(i<wordList.childElementCount) div=wordList.children[i]; else div=wordTemplate.cloneNode(true);
            
            if(div.nodeName!=="DIV") {var newDiv=document.createElement("div"); wordList.replaceChild(newDiv, div); div=newDiv}; //useful for Firefox
            
            var wordTab=word[i].text.split(orSeparator);
            for(var j=div.childElementCount; j<2*wordTab.length-1; j++) {
                var span = document.createElement("span");
                div.appendChild(span); 
                var text = document.createTextNode("");
                span.appendChild(text); 
            }
            while(div.childElementCount>2*wordTab.length-1) {
                div.removeChild(div.lastElementChild); 
            }
            
            var span=div.firstElementChild;
/*
            span.classList="";
            span.classList.add(tagRound+loc); span.classList.add(darkTheme[darkMode]);
            span.style="";
            if(highlightActive && word[i].on && highlightStyle!==2) setHighlightStyle(span, col); else unsetHighlightStyle(span);
            if(word[i].text)
            {
                if(span.firstChild && span.firstChild.nodeName=="#text") span.firstChild.nodeValue=word[i].text;
                else span.replaceChildren(document.createTextNode(word[i].text));
            }
            else
            {
                span.replaceChildren(document.createElement("br"));
            }
*/
            for(var j=0; j<wordTab.length; j++)
            {
                if(span.nodeName==="BR") {var newSpan=document.createElement("span"); div.replaceChild(newSpan, span); span=newSpan;}
                
                span.classList="";
                span.classList.add(tagRound+loc); span.classList.add(darkTheme[darkMode]);
                span.style="";
                if(highlightActive && word[i].on && highlightStyle!==2 && (oneChar || wordTab[j].length>1)) setHighlightStyle(span, col); else unsetHighlightStyle(span);
                //if(word[i].text)
                if(wordTab[j]=="" && j==wordTab.length-1)//wordTab.length==1)
                {
                    span.replaceChildren(document.createElement("br"));
                }
                else
                {
                    //if(span.firstChild && span.firstChild.nodeName=="#text") span.firstChild.nodeValue=word[i].text;
                    //else span.replaceChildren(document.createTextNode(word[i].text));
                    if(span.firstChild && span.firstChild.nodeName=="#text") span.firstChild.nodeValue=wordTab[j];
                    else span.replaceChildren(document.createTextNode(wordTab[j]));
                }
                
                if(j!=wordTab.length-1)
                {
                    span=span.nextSibling; span.style.color=theme?"lightpink":"red"; span.style.backgroundColor="unset";
                    if(span.firstChild && span.firstChild.nodeName=="#text") span.firstChild.textContent=orSeparator;
                    else span.replaceChildren(document.createTextNode(orSeparator));
                }
                span=span.nextSibling;
            }
            
            if(i>=wordList.childElementCount) tempWordList.appendChild(div);  
        }
        while(wordList.childElementCount>word.length) wordList.removeChild(wordList.childNodes[word.length]); 
        wordList.appendChild(tempWordList);

        if(options[3])
        {
        var tempJumpID = document.createDocumentFragment();
        for(var i=0; i<word.length; i++)
        {
            var div;
            if(i<jumpID.childElementCount) div = jumpID.children[i]; else div = jumpTemplate.cloneNode(true);
            var span  = div.firstElementChild;
            var bUp   = div.children[1]; bUp.onclick=jumpUp;
            var bDown = div.children[2]; bDown.onclick=jumpDown;
            
            span.classList = darkTheme[darkMode];
            if(highlightActive && word[i].on && highlightStyle!==2 && wordCount && wordCount[i])
            {
                var col=word[i].colIndex;
                setHighlightStyle(span, col);
            }
            else
            {
                unsetHighlightStyle(span, col);
            }
            bUp.setAttribute("HL-word", i);
            //bUp.disabled=(!wordCount || +wordCount[i]==0);
            if(!wordCount || +wordCount[i]==0) bUp.classList.add("disabled"); else bUp.classList.remove("disabled");   
            
            bDown.setAttribute("HL-word", i);
            //bDown.disabled=(!wordCount || +wordCount[i]==0);
            if(!wordCount || +wordCount[i]==0) bDown.classList.add("disabled"); else bDown.classList.remove("disabled");   
            
            var str = (!wordCount || isNaN(wordCount[i])) ? "-" : +wordCount[i];
            if(i==wordSelect) str=(wordOcc+1)+"/"+str;
            
            span.firstChild.nodeValue=str;
            
            var wordTab=word[i].text.split(orSeparator);        
            var moreThanOne=false;
            for(var j=0; j<wordTab.length; j++) if(wordTab[j].length>1) moreThanOne=true;
            //if(word[i] && (oneChar || moreThanOne))
            /*
            if(word[i] && wordCount[i])
            {
                bUp.style.opacity="1";
                bDown.style.opacity="1";
                bUp.style.opacity="1";
                bDown.style.opacity="1";
                //span.style.opacity="1";
            }
            else
            {
                bUp.style.opacity="0";
                bDown.style.opacity="0";
                //span.style.opacity="0";
            } 
            */ 
            //span.style.opacity="1"; 

            if(i>=jumpID.childElementCount) tempJumpID.appendChild(div);  
        }
        while(jumpID.childElementCount>word.length) jumpID.removeChild(jumpID.childNodes[word.length]);
        jumpID.appendChild(tempJumpID);  
           
        var str=(wordCount) ? wordCount.reduce((a, b) => (+a) + (+b), 0)+" " : "- "; 
        if(wordOcc!=-1) str=(globalOcc+1)+"/"+str;
        totalNumber.textContent=str;
        }
        
        if(options[10])
        {
            var tempOptID = document.createDocumentFragment();
            for(var i=0; i<word.length; i++)
            {
                var div;
                if(i<optID.childElementCount) div = optID.children[i]; else div = optTemplate.cloneNode(true);
                var bVisibleLbl  = div.firstElementChild;
                var bVisible     = bVisibleLbl.firstElementChild; bVisible.onclick=changeVisible;
                var bColor      = div.children[1]; bColor.onclick=chooseColorToBeChanged;

                bVisible.checked=word[i].on;
                bVisible.setAttribute("HL-word", i);

                if(word[i].text)
                {
                    bVisibleLbl.style.opacity="1";
                    //bVisibleLbl.disabled=(!wordCount || +wordCount[i]==0);
                    if(!wordCount || +wordCount[i]==0) bVisibleLbl.classList.add("disabled"); else bVisibleLbl.classList.remove("disabled");   
                }
                else
                {
                    bVisibleLbl.style.opacity="0";
                    //bVisibleLbl.disabled=true;
                    bVisibleLbl.classList.add("disabled"); 
                    
                }
                bColor.style.backgroundColor=highlightColor[theme][word[i].colIndex].back;
                bColor.setAttribute("HL-word", i);
     
                if(i>=optID.childElementCount) tempOptID.appendChild(div); 
            }
            while(optID.childElementCount>word.length) optID.removeChild(optID.childNodes[word.length])
            optID.appendChild(tempOptID);//appendChild(fragment)
        }
        //restoreSelection(from+">updateWordListDisplay()");
        //console.log("before", JSON.stringify(sel.selBeg));
        
        sel.selBeg=updateXYfromSelection(sel.selBeg, from);
        sel.selEnd=updateXYfromSelection(sel.selEnd, from);
        //sel.selEnd = {x:sel.selBeg.x, xMax:sel.selBeg.xMax, y:sel.selBeg.y, yMax:sel.selBeg.yMax, dx:sel.selBeg.dx, dxMax:sel.selBeg.dxMax};
        
        //console.log("after ", JSON.stringify(sel.selBeg));
        var range = document.createRange();
        var selection = window.getSelection();
        if(wordList.children.length===0)                                                      range.setStart(wordList, 0);
        else if(wordList.children[sel.selBeg.y].children.length===0)                          range.setStart(wordList.children[sel.selBeg.y], 0);
        else if(wordList.children[sel.selBeg.y].children[sel.selBeg.x]?.childNodes.length==0) range.setStart(wordList.children[sel.selBeg.y].children[sel.selBeg.x], 0);
        else                                                                                  range.setStart(wordList.children[sel.selBeg.y].children[sel.selBeg.x].firstChild, sel.selBeg.dx);

        if(wordList.children.length===0)                                                      range.setEnd(wordList, 0);
        else if(wordList.children[sel.selBeg.y].children.length===0)                          range.setEnd(wordList.children[sel.selEnd.y], 0);
        else if(wordList.children[sel.selBeg.y].children[sel.selBeg.x].childNodes.length===0) range.setEnd(wordList.children[sel.selEnd.y].children[sel.selEnd.x], 0);
        else                                                                                  range.setEnd(wordList.children[sel.selEnd.y].children[sel.selEnd.x].firstChild, sel.selEnd.dx);

        //range.collapse();
        
        //document.removeEventListener("selectionchange", selectionChange);
        selection.removeAllRanges();
        selection.addRange(range);
        //document.addEventListener("selectionchange", selectionChange);
    }

    //requestAnimationFrame(function() {
        sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
    //});
    if(DBG) t1=Date.now();
    if(DBG) console.log("* updateWordListDisplay(",from,")", t1-t0);
}  

function jumpUp()
{
  var n=this.getAttribute?this.getAttribute("HL-word"):null;
  if(n===null) n=-1;
  sendMessage({action:"doUp", param:n});   
}
function jumpDown()
{
  var n=this.getAttribute?this.getAttribute("HL-word"):null;
  if(n===null) n=-1;
  sendMessage({action:"doDown", param:n});       
}
function changeVisible()
{
  var n=this.getAttribute?this.getAttribute("HL-word"):null;
  if(n===null) n=-1;
  word[n].on=this.checked;
  //word[n].on=!word[n].on;
  //this.checked=word[n].on;
  //this.firstChild.firstChild.src=  word[n].on ? charOn : charOff;  
   wordOcc=-1; wordSelect=-1; globalOcc=-1;
  //updateWordListDisplay("changeVisible()");
   chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
      //if(DBG) console.log('Multi Find> doRecord>', "page=", page, "display=", display, "search=", search);
      sendMessage2({action:"updateOtherWindows", from:"changeVisible()"});
  });

}
 
var isElement = (node, tag) => node && node.nodeType===Node.ELEMENT_NODE && node.tagName===tag; 

var isNode = (node, name) => node && node.nodeName===name; 
var isText = (node, tag) => node && node.nodeType===Node.TEXT_NODE; 
var textContent = (node) => node ? (node.nodeType===Node.TEXT_NODE ? node.textContent: node.innerText) : "";


function getXYfromSelection(node, offset, from)
{
    var span=node; // if <span> contains a <br>, <span> is sent
    var x, xMax, y, yMax, dx, dxMax;
    if(span.nodeName==="DIV")
    {
        var aaaa=0;
    }

    if(node.nodeName==="#text") {span=node.parentNode;}
    if(node.nodeName==="BR") {span=node.parentNode;} //should never happen (<br> is not selectable)
    if(span.nodeName==="SPAN" || span.nodeName==="DIV")
    {
        if(span.nodeName==="DIV") //<div><br></div> (happens if backspace on empty line)
        {
            dx=0; dxMax=0; //span.nodeName==="DIV"
            x=0; xMax=1; //span.nodeName==="DIV"
            var div=span;
            var root=div.parentNode;
            if(root===wordList)
            {
              var tabY=Array.from(wordList.children);
              y=tabY.indexOf(div);
              yMax=tabY.length;
            }
        }
        if(span.nodeName==="SPAN")
        {
            if(span.firstChild.nodeName==="#text") {dx=offset; dxMax=span.textContent.length;} //span.nodeName==="SPAN"
            if(span.firstChild.nodeName==="BR") {dx=0; dxMax=0;} //<span><br></span>
            
            var div=span.parentNode;
            
            if(div.nodeName==="DIV")
            {
                var tabX=Array.from(div.children);
                x=tabX.indexOf(span);
                xMax=tabX.length;
                
                //if(x==0 && span.textContent===orSeparator) {xMax++; x++;} // if the string is beginning by a separator a "" added before later: count it now.
                //if(x==xMax-1 && span.textContent===orSeparator) xMax++; //if the string is ending by a separator a <BR> will be added after later: count it now.
                
                //fix the values if the separator is selected
                if(x%2===1 && dx===dxMax && x<xMax-1) {x=x+1; span=div.children[x]; dx=0;                       dxMax=span?.textContent.length||0;}
                //if(x%2===1 && dx===0    ) {x=x-1; span=div.children[x]; dx=span.textContent.length; dxMax=span.textContent.length;}
                
                //fix the value of xMax end of string and if next string is not a seperator
                if(dx===dxMax && x<xMax-1 && div.children[x+1].textContent!=orSeparator) {xMax--; dxMax+=div.children[x+1].textContent.length;}
                 
                if(tabX[0].textContent===orSeparator) {xMax++; x++;} // if the string is beginning by a separator a "" added before later: count it now.
                if(tabX[tabX.length-1].textContent===orSeparator) xMax++; //if the string is ending by a separator a <BR> will be added after later: count it now.
 
                var root=div.parentNode;
                if(root===wordList)
                {
                  var tabY=Array.from(wordList.children);
                  y=tabY.indexOf(div);
                  yMax=tabY.length;
                }
            }
        }
    }
    //console.log("getXYfromSelection", node, JSON.stringify({x,xMax,y,yMax,dx,dxMax}), from);
    return {x,xMax,y,yMax,dx,dxMax};
}

function selectionChange()
{
    var range = window.getSelection().rangeCount? window.getSelection().getRangeAt(0):null;
    if(!range || !wordList.contains(range.startContainer)) return;
    
    sel.selBeg = getXYfromSelection(range.startContainer, range.startOffset, "selectionChange()");
    sel.selEnd = getXYfromSelection(range.endContainer,   range.endOffset, "selectionChange()");
    //sel.selEnd = {x:sel.selBeg.x, xMax:sel.selBeg.xMax, y:sel.selBeg.y, yMax:sel.selBeg.yMax, dx:sel.selBeg.dx, dxMax:sel.selBeg.dxMax};
}

function selectionToEnd()
{
    return  {selBeg:{x:0, xMax:1, y:0, yMax:1, dx:0, dxMax:0}, selEnd:{x:0, xMax:1, y:0, yMax:1, dx:0, dxMax:0}};
}

function textareaChangeAndRecord(from)
{
    textareaChange(from);
    doRecord(word.map(a=>a.text).join('\n'));
}

//updates word when the wordList (contentedit div rather than textarea) changes
function textareaChange(from)//optimiser
{
    //console.log("textareaChange(from):", from)
    //selectionChange();  
    var rawText=[], rawTextIndex=0;
    var level0=wordList;
    for(var level1=level0.firstChild; level1; level1=level1.nextSibling)
    {
        var text=level1.textContent;            
        if(text=="" || text=="\n" || text=="\r") //empty line
        {
            rawText[rawTextIndex++]="";
        }
        else
        {
            var textTab=text.split(/\r\n|\n|\r/); //if line breaks, give the correct structure
            for(let i=0; i<textTab.length; i++)  
            {
                rawText[rawTextIndex++]=textTab[i];
            }
        }  
    }
    
    
    //updates word array
    
    //maintains color consistency
    var newWord=[];
    var alpha=0; var beta=rawTextIndex;
    var a=0; var b=word.length;
    if(DBG) console.log("before 0 rawTextIndex", rawTextIndex, "word.length", word.length, "alpha:", alpha, "beta:", beta, "a:", a, "b:", b);
    while(alpha<rawTextIndex && a<word.length && rawText[alpha]==word[a].text) {newWord[alpha]={text:word[a].text, on:word[a].on, colIndex:word[a].colIndex}; alpha++; a++;};
    if(DBG) console.log("before 1 rawTextIndex", rawTextIndex, "word.length", word.length, "alpha:", alpha, "beta:", beta, "a:", a, "b:", b);
    while(beta>alpha && b>a && rawText[beta-1]==word[b-1].text) {newWord[beta-1]={text:word[b-1].text, on:word[b-1].on, colIndex:word[b-1].colIndex}; beta--; b--;};
    if(DBG) console.log("before 2 rawTextIndex", rawTextIndex, "word.length", word.length, "alpha:", alpha, "beta:", beta, "a:", a, "b:", b);
    if(alpha==beta-1 && a<word.length && a<b) newWord[alpha]={text:word[a].text, on:word[a].on, colIndex:word[a].colIndex};
    for(var i=alpha; i<beta; i++)
    {
        var found=word.findIndex(a=>a.text===rawText[i])
        if(rawText[i] && found!=-1) newWord[i]={text:word[found].text, on:word[found].on, colIndex:word[found].colIndex};
        else
        {
            if(i<b) newWord[i]={text:rawText[i], on:word[i].on, colIndex:word[i].colIndex};//i<b instead of i<word.length, but why not i>=a?
            else newWord[i]={text:rawText[i], on:true, colIndex:(i%colorRange+colorOffset)%colorMax};
        }
    }
    word=newWord;
    if(DBG) console.log("after  0 rawTextIndex", rawTextIndex, "word.length", word.length, "alpha:", alpha, "beta:", beta, "a:", a, "b:", b);
   
    //saving word to local storage
    chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
        wordOcc=-1; wordSelect=-1; globalOcc=-1;
        updateWordListDisplay("textareaChange"); //applies the proper formatting
    });
    
}

function updateXYfromSelection(selBeg, from)
{
    //console.log(from+">restoreSelection()", selBeg);
    //console.log("updXYfromSelectio0", JSON.stringify({x:selBeg.x, xMax:selBeg.xMax, y:selBeg.y, yMax:selBeg.yMax, dx:selBeg.dx, dxMax:selBeg.dxMax}));

    var x,y,dx;

    if(!suppression)
    {
        var yMax=wordList.children.length;
        if(yMax - (selBeg.yMax-selBeg.y) >= 0) y = yMax - (selBeg.yMax-selBeg.y); else return {x:wordList?.firstChild?.children.length-1||0, xMax:wordList?.firstChild?.children.length||1, y:0, yMax, dx:wordList?.firstChild?.children[wordList.children[0].children.length-1].textContent.length||0, dxMax:wordList?.firstChild?.children[wordList.children[0].children.length-1].textContent.length||0};

        var xMax=wordList.children[y].children.length;
        if(xMax - (selBeg.xMax-selBeg.x) >= 0) x = xMax - (selBeg.xMax-selBeg.x); else return {x:0, xMax, y, yMax, dx:0, dxMax:wordList.children[y]?.firstChild?.textContent.length||0};

        var dxMax=wordList.children[y]?.children[x]?.textContent.length||0;
        if(dxMax - (selBeg.dxMax-selBeg.dx) >= 0) dx = dxMax - (selBeg.dxMax-selBeg.dx); else return {x, xMax, y, yMax, dx:0, dxMax};       
    }
    else
    {
        var yMax=wordList.children.length;
        if(yMax - selBeg.y >= 0) y = selBeg.y; else return {x:wordList?.firstChild?.children.length-1||0, xMax:wordList?.firstChild?.children.length||1, y:0, yMax, dx:wordList?.firstChild?.children[wordList.firstChild.children.length-1].textContent.length||0, dxMax:wordList?.firstChild.children[wordList.firstChild.childNodes.length-1].textContent.length||0};

        var xMax=wordList.children[y].children.length;
        if(xMax - selBeg.x >= 0) x = selBeg.x; else return {x:0, xMax, y, yMax, dx:0, dxMax:wordList.children[y]?.firstChild?.textContent.length||0};

        var dxMax=wordList.children[y].children[x].textContent.length;
        if(dxMax - selBeg.dx >= 0) dx = selBeg.dx; else return {x, xMax, y, yMax, dx:0, dxMax}; 
    }  
    
    //console.log("updXYfromSelectio1", JSON.stringify({x,xMax,y,yMax,dx,dxMax}));
    return {x, xMax, y, yMax, dx, dxMax};   
}


//when the user clicks on the checkox (or the toggle slider)
function checkboxChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> checkboxChange>");
  highlightActive=onBox.checked;
  //updateWordListDisplay("checkboxChange");
  //saving highlightActive to local storage
  //chrome.storage.local.set({highlightActive:highlightActive}).then(()=>{
  chrome.storage.local.set({version, display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"checkboxChange(e)"});
      //sendMessage2({action:"updateOtherWindows", from:"locChange()"});//it's only when the menu will be closed that the changes will apply
   });
   wordList.focus();
}

function majChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> majChange>");
  maj=this.checked;
  wordOcc=-1; wordSelect=-1; globalOcc=-1;

  //saving maj to local storage
  //chrome.storage.local.set({maj:maj}).then(()=>{
  chrome.storage.local.set({version, search:{maj, diac, loc, oneChar}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"majChange(e)"});
   });
   wordList.focus();
}
function diacChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> majChange>");
  diac=this.checked;
  wordOcc=-1; wordSelect=-1; globalOcc=-1;
  //saving maj to local storage
  //chrome.storage.local.set({diac:diac}).then(()=>{
  chrome.storage.local.set({version, search:{maj, diac, loc, oneChar}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"diacChange(e)"});
   });
   wordList.focus();
}
function scrollChange(e)
{
  //e.preventDefault();
  //if(DBG) console.log("Multi Find> scrollChange>");
  scrollActive=this.checked;
  //saving scrollActive to local storage
  //chrome.storage.local.set({scrollActive:scrollActive}).then(()=>{
  chrome.storage.local.set({version, display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"scrollChange(e)"});
   });
   wordList.focus();
}

function focusPopup()
{
  if(DBG)
    document.body.style.backgroundColor="#FF8";
  fileFinder=false;
  if(DBG) console.log("Multi Find> focusPopup>", "fileFinder =", fileFinder);
}

function closePopup()
{
  //if(DBG) console.log("Multi Find> closePopup>");
  //saving sel to local storage
  popupOn=false;
  chrome.storage.local.set({version:version, page:{word, sel, doAction, doIndex}, display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}}).then(()=>{
      sendMessage({action:"requestClosePopup", from:"closePopup()"});
      //if(!DBG) window.close(); //remove this line to debug the popup window
  });
}

var fileFinder=false;
function blurPopup()
{
  if(DBG)
    document.body.style.backgroundColor="#CCC";
  if(DBG) console.log("Multi Find> blurPopup>", "fileFinder =", fileFinder);
  //saving sel to local storage
  if(!fileFinder)
  {
    popupOn=false;
    chrome.storage.local.set({version:version, page:{word, sel, doAction, doIndex}, display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}}).then(()=>{
        if(!persistentMenu) sendMessage({action:"requestClosePopup", from:"blurPopup()"});
    });
  }
}

//when the user clicks on the checkox (or the toggle slider)
function locChange()
{
  //if(DBG) console.log("Multi Find> locChange>");
  if(this==loc0ID) loc=0;
  if(this==loc1ID) loc=1;
  if(this==loc2ID) loc=2;
  if(this==loc3ID) loc=3;
  loc0ID.classList.remove("pushed"); loc1ID.classList.remove("pushed"); loc2ID.classList.remove("pushed"); loc3ID.classList.remove("pushed");
  this.classList.add("pushed");
  wordOcc=-1; wordSelect=-1; globalOcc=-1;
  updateWordListDisplay("locChange");
  //saving loc to local storage
  //chrome.storage.local.set({loc:loc}).then(()=>{
  chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}, search:{maj, diac, loc, oneChar}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"locChange()"});
  });
  wordList.focus();
}

function allChange()
{
  //if(DBG) console.log("Multi Find> allChange>");
  //saving loc to local storage
  chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}, display:{highlightActive, highlightColor, scrollActive, scrollX, counterOn, persistentMenu, persistentMenuX, persistentMenuY, transparentMenu, darkMode, colorOffset, colorRange, popupOn, style:highlightStyle/*tagStyle==='HL-glow-'*/}, search:{maj, diac, loc, oneChar}}).then(()=>{
      //if(DBG) console.log('Multi Find> allChange>', "page=", page, "display=", display, "search=", search);
      //sendMessage2({action:"updateOtherWindows", from:"allChange()"});// ???
  });
}
function doRecord(newText)
{
  //wordList.setHTML(text);
  doAction[doIndex++]={oldText, newText};
  doAction.splice(doIndex); //forget any subsequant actions that was registred
  if(doIndex===doAction.length) tool7ID.classList.add("disabled"); else  tool7ID.classList.remove("disabled");   
  if(doIndex===0) tool6ID.classList.add("disabled"); else tool6ID.classList.remove("disabled");   
  //wordList.textContent = newText;
  oldText=newText;
  
  while(JSON.stringify(doAction).length>doActionSizeMax) {doAction=doAction.slice(1); doIndex--;}
  if(DBG) console.log(doAction);
  
  chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
      //if(DBG) console.log('Multi Find> doRecord>', "page=", page, "display=", display, "search=", search);
      sendMessage2({action:"updateOtherWindows", from:"doRecord(newText)"});
  });
  

  //textareaChange();
}

function toolUndo()
{
  if(doIndex>0)
  {
    doIndex--;
    wordList.textContent =  doAction[doIndex].oldText;
    oldText=doAction[doIndex].oldText;
    textareaChange();    
    if(doIndex===doAction.length) tool7ID.classList.add("disabled"); else  tool7ID.classList.remove("disabled");   
    if(doIndex===0) tool6ID.classList.add("disabled"); else tool6ID.classList.remove("disabled");   
    //textareaChangeAndRecord();
    chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
      //if(DBG) console.log('Multi Find> doRecord>', "page=", page, "display=", display, "search=", search);
      sendMessage2({action:"updateOtherWindows", from:"toolUndo()"});
    });
  }  
  wordList.focus();
}

function toolRedo()
{
  if(doIndex<=doAction.length-1)
  {
    wordList.textContent =  doAction[doIndex].newText;
    oldText=doAction[doIndex].newText;
    doIndex++;
    textareaChange();    
    if(doIndex===doAction.length) tool7ID.classList.add("disabled"); else  tool7ID.classList.remove("disabled");   
    if(doIndex===0) tool6ID.classList.add("disabled"); else tool6ID.classList.remove("disabled");   
    //textareaChangeAndRecord();
    chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
      //if(DBG) console.log('Multi Find> doRecord>', "page=", page, "display=", display, "search=", search);
      sendMessage2({action:"updateOtherWindows", from:"toolRedo()"});
    });
  }  
  wordList.focus();
}
function fileToWords(e) {
  //if(DBG) console.log(e.target.result);
  
  wordList.textContent = e.target.result;
  //word=[];//?
  textareaChangeAndRecord("fileToWords(e)");

  //word=e.target.result.split('\n');
  //updateWordListDisplay("fileToWords");
}


//when the user clicks on the toolbox button
function getTimestamp() {
  const date = new Date();
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, '0');
  const day =`${date.getDate()}`.padStart(2, '0');
  const hour =`${date.getHours()}`.padStart(2, '0');
  const minute =`${date.getMinutes()}`.padStart(2, '0');
  const second =`${date.getSeconds()}`.padStart(2, '0');
  return `${year}-${month}-${day} ${hour}-${minute}-${second}`
}

function toolLoad(e)
{
  fileFinder=true; //about ot open a file finder
  if(DBG) console.log("Multi Find> toolLoad>", "fileFinder =", fileFinder);
  var file = e.target.files[0]; //tool0IDh.files[0];
  tool0IDh.value = "";  // so I can reload the same file again
  var reader = new FileReader();
  reader.addEventListener('load', fileToWords);
  //reader.readAsText(file);
  reader.readAsText(file, 'UTF-8');
  //fileFinder=false;
  wordList.focus();
}
function toolSave(e)
{
  fileFinder=true; //about ot open a file finder
  if(DBG) console.log("Multi Find> toolSave>", "fileFinder =", fileFinder);
  var saveText=wordList.innerText;
  
  var link = document.createElement("a");
  document.body.appendChild(link);

  link.href = "data:text/plain," + encodeURIComponent(saveText);
  link.style = "display: none";
  link.download = "MultiFind "+getTimestamp()+".txt";
  link.click();
  
  //document.body.removeChild(link);//to be added?
  URL.revokeObjectURL(link.href);
  //fileFinder=false;
  wordList.focus();
}
function toolClearAll()
{
  wordList.textContent = "";
  //word=[]; //?
  sel=selectionToEnd();
  textareaChangeAndRecord("toolClearAll()");
  wordList.focus();
}
function toolClearNotFound()
{
  var newWord=[];
  for(var i=0; i<word.length; i++) if(wordCount[i])  newWord.push(word[i]);
    
  word=newWord;  
  wordList.textContent = newWord.map(a=>a.text).join('\n');
  if(wordList.textContent == "") sel=selectionToEnd();
  textareaChangeAndRecord("toolClearNotFound()");
  wordList.focus();
}
function toolClearFound()
{
  var newWord=[];
  for(var i=0; i<word.length; i++) if(word[i]!=="" && !wordCount[i])  newWord.push(word[i]);

  word=newWord;
  wordList.textContent = newWord.map(a=>a.text).join('\n');
  if(wordList.textContent == "") sel=selectionToEnd();
  //wordCount= wordAndFreq.map(a=>a.count);
  textareaChangeAndRecord("toolClearFound()");
  wordList.focus();
}
function toolSortAlpha()
{
  var wordAndFreq=[];
  for(var i=0; i<word.length; i++) wordAndFreq.push({word:word[i], count:wordCount[i]});
  wordAndFreq=wordAndFreq.filter(a=>a.word.text!=="");
  wordAndFreq.sort((a, b) => a.word.text.localeCompare(b.word.text, undefined, {sensitivity: 'base'}));

  word=wordAndFreq.map(a=>a.word);
  wordList.textContent = wordAndFreq.map(a=>a.word.text).join('\n');
  wordCount= wordAndFreq.map(a=>a.count);
  textareaChangeAndRecord("toolSortAlpha()");
  wordList.focus();
}
function toolSortFreq()
{
  var wordAndFreq=[];
  for(var i=0; i<word.length; i++) wordAndFreq.push({word:word[i], count:wordCount[i]});
  wordAndFreq=wordAndFreq.filter(a=>a.word.text!=="");
  //word.sort();
  wordAndFreq.sort((a, b) => b.count-a.count);

  word=wordAndFreq.map(a=>a.word);
  wordList.textContent = wordAndFreq.map(a=>a.word.text).join('\n');
  
  textareaChangeAndRecord("toolSortFreq()");
  wordList.focus();
}

function moveSearchWindow()
{
    if(this.id=="move-left")
    {
        sendMessage({action:"moveSearch", dir:"left"});
        moveLeft.style.display="none";
        moveRight.style.display="block";
    }
    if(this.id=="move-right")
    {
        sendMessage({action:"moveSearch", dir:"right"});
        moveRight.style.display="none";
        moveLeft.style.display="block";
    }
    if(this.id=="move-top")
    {
        sendMessage({action:"moveSearch", dir:"top"});
        moveTop.style.display="none";
        moveBottom.style.display="block";
    }
    if(this.id=="move-bottom")
    {
        sendMessage({action:"moveSearch", dir:"bottom"});
        moveBottom.style.display="none";
        moveTop.style.display="block";
    }
}

function updateColorPicker(theme)
{
  //if(colorPicker.style.height!="0px") colorPicker.style.height=32*Math.floor(colorRange/10+1)+"px";
  for(var i=0; i<colorMax; i++) {
    if(i<colorRange)
    {
        colorsElement[i].style.backgroundColor=highlightColor[theme][i].back;
        //colorsElement[i].style.height="100%";
        colorsElement[i].classList="color-swatch";
        colorsElement[i].style.display="";
        colorsElement[i].firstChild.style.color=highlightColor[theme][i].front;
        colorsElement[i].firstChild.textContent=i+1;
    }
    else
    {
        colorsElement[i].style.display="none";    
    }  
  }
}

var colorPickerHeightOpen;
var colorPickerHeightClosed = "0px";

function chooseColorToBeChanged()
{
    choosenCol=+this.getAttribute("HL-word");
    if(colorPicker.style.height==colorPickerHeightClosed || colorPicker.style.height=="")//the second test is an anti-bug
    {
        var buttonRect = this.getBoundingClientRect();
        colorPicker.style.left=buttonRect.left + 'px';
        colorPicker.style.top=buttonRect.bottom + 'px';
        colorPicker.style.height=colorPickerHeightOpen;

    }
    else colorPicker.style.height=colorPickerHeightClosed;
    //requestAnimationFrame(function() {
        sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
    //});
}

function pickNewColor()
{
    var colNum=+this.id.slice("color".length, "color".length+2);
    word[choosenCol].colIndex=colNum;
    colorPicker.style.height=colorPickerHeightClosed;
    //requestAnimationFrame(function() {
        sendMessage({action:"answerHeight", height:document.body.scrollHeight, width:document.body.scrollWidth});
    //});
    chrome.storage.local.set({version, page:{word, sel, doAction, doIndex}}).then(()=>{
      sendMessage2({action:"updateOtherWindows", from:"pickNewColor()"});
    });
}

function sendMessage(message)
{
  //message.from="popup";
  if(DBG) console.log("sendMessage from popup to main", message);
  window.parent.postMessage(message, '*'); //send message from popup to main window

}

function sendMessage2(message)
{
  //var conn=document.getElementById("connID");
  chrome.runtime.sendMessage(message, {}, function (response) {
    if(DBG) console.log("popup > sendMessage2 (", message, ")");
    if (!chrome.runtime.lastError && response.received=="OK") {
    } else {
    }
  });
}
