//Multi Find, Vincent Greco, 2023-24
"use strict";

var DBG = false;
var overlayOn = false;/* experimental*/


var word = [];
var wordRegex = [];
var highlightActive;
var maj;
var diac;
var scrollActive;
var loc;
var unicode;
var oneChar   = false;
var popupOn   = false;
var counterOn = true;
var darkMode = 0;

var scrollbarParent=null;
var scrollbarDiv = null;
var scrollbarButton = null;

var scrollbarCanvas = null;
var scrollbarWidth = 18;  //must be more than 10 (the width of the marker)
var resizeTimeout = null;
var updateAllDocTimeout = null;

var selectParam = {wordCount:[], wordSelect:-1, wordOcc:-1, globalOcc:-1};

var tagNameFound              = 'MULTI-FIND-1-EXTENSION';
var tagNameDummy              = 'MULTI-FIND-0-EXTENSION';
var tagNameFoundShort         = 'MULTI-FIND-1';
var tagNameDummyShort         = 'MULTI-FIND-0';
var tagNameTextareaShort      = 'MULTI-FIND-3';
var tagNameTextareaDummyShort = 'MULTI-FIND-2';

var highlightStyle=0;
//var tagStyle = 'HL-glow-';
var tagRound = 'HL-round-'; 
var darkTheme = ['HL-light-theme', 'HL-system-theme', 'HL-dark-theme'];
var colorOffset =  0;
var colorRange  = 10;
var colorMax    = 20;
var orSeparator="|";

var rectSel={x:0, left:0, right:0, y:0, top:0, bottom:0};
var currentSelection=false;
var observer;

var iframe;
var isActiveElement = false;
var highlightColor, lineColor;
var askedForUpdatePopup=false;

var multiFindWin=null;
var multiFindWinDiv=null;

var focusID=0;

//var triLeftChar  = '\u25C2';
//var triRightChar = '\u25B8';
var triLeftChar  = '\u25C0';
var triRightChar = '\u25B6';


function afterLoad()
{
  if(document.body.clientHeight===0 && document.body.clientWidth===0) return; //anti-bug
  
  const script = document.createElement('script');
  // Set the source attribute to the external script file
  script.src = chrome.runtime.getURL('multi-find-element.js');
  // Append the script to the document head to load the external script
  document.head.appendChild(script);


   
  //document.body.style.backgroundColor = "green" ;
  var s=getComputedStyle(document.documentElement);
  lineColor=[s.getPropertyValue('--HL-line-light-0'), '#FFF' /*s.getPropertyValue('--HL-line-dark-0')*/]
  
  iframe = (window !== window.parent);
  if(!iframe) isActiveElement=true;
  
  if(!iframe)
  {
    [multiFindWin, multiFindWinDiv]=createPopup();
    isActiveElement=true;
    //contentSendMessageToPopup({action:"updateWordCount", wordCount:selectParam.wordCount, wordSelect:selectParam.wordSelect, wordOcc:selectParam.wordOcc, globalOcc:selectParam.globalOcc});
  }

  
  addCustomScrollbar();
  //updateAllDocHighlightsWhenStabilized();     // done in sw.js now (onUpdated)

  // Create an observer instance
  observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      //observer.disconnect();
      var elements = [];
      if(mutation.type === "childList") {
        if (mutation.addedNodes && mutation.addedNodes.length > 0) {
          for (var i = 0; i < mutation.addedNodes.length; i++) {
            var node = mutation.addedNodes[i];
            if (node.tagName === tagNameFound) {
              continue; //filter it
            }
            elements.push(node);
          }
        }
      } else if (mutation.type === "characterData") {
        var node = mutation.target;
        elements.push(node);
      } 
      observer.disconnect();
      if((highlightActive /*|| popupOn*/) && elements.length)
      {
        //if(DBG) console.log("highlightElementRec from observer")
        for (var i = 0; i < elements.length; i++)
          if(elements[i].isConnected && elements[i].parentNode) // still attached to the DOM
          {
            var sel= window.getSelection();
            var range = sel.rangeCount? sel.getRangeAt(0):null;
            if (elements[i].parentNode.tagName === tagNameFound)
            {
              highlightElementRec(removeOneHighlight(elements[i].parentNode, range), wordRegex, range);
            }
            else
            {
             highlightElementRec(elements[i], wordRegex, range);
            }
          }
        drawScrollbarWhenStabilized();
      }
      observer.observe(document.body, { characterData: true, childList: true, subtree: true });
    });
  });

  // Start observing the target node
  observer.observe(document.body, { characterData: true, childList: true, subtree: true });

  // Create a new MutationObserver
  const observer2 = new MutationObserver(function(mutationsList) {
    for (let mutation of mutationsList) {
      if (mutation.type === 'attributes') {
        updateStyle(mutation.target);
      }
    }
  });

  const textareas = document.querySelectorAll('textarea, input[type="text"], input[type="search"], input[type="button"]');
  // Observe changes in attributes of all <textarea> and <input> elements
  textareas.forEach(function(textarea) {
    observer2.observe(textarea, { attributes: true });
  });
  //contentSendMessageToPopup({action:"askForFocus"});

  /*
  inputs.forEach(function(input) {
    observer2.observe(input, { attributes: true });
  });
  */
   window.addEventListener("focus", function (e) {
    //e.preventDefault();
    var win=document.activeElement.ownerDocument.defaultView;
    if(!iframe && win.parent===win || iframe && win.parent!==win) //this is me! (???)
    {
        //isActiveElement=true;
        //drawScrollbarWhenStabilized();
        focusID=Math.floor(Math.random()*9999+1);
        contentSendMessageToBackground({action:"askForFocus", focusID, from:"content-script.js > drawScrollbar()", global:-1});
    }
  }, true);

  var selText="";
  document.addEventListener("selectionchange", function() {
    var selection = window.getSelection(); // Get the current selection
    selText=selection.toString();
    if (selection.rangeCount>0) // If the selection is not empty
    {
      const range = selection.getRangeAt(0); // Get the first range of the selection
      var rectSel0 = range.getBoundingClientRect(); // get the bounding rectangle (read only)
      rectSel={x:rectSel0.x, left:rectSel0.left, right:rectSel0.right, y:rectSel0.y, top:rectSel0.top, bottom:rectSel0.bottom, width:rectSel0.width, height:rectSel0.height};
      //if(DBG) console.log("1) rect=", rectSel);
      //var doc = document.documentElement; 
      var doc = document.scrollingElement; 
     
      rectSel.x+=doc.scrollLeft;
      rectSel.left+=doc.scrollLeft;
      rectSel.right+=doc.scrollLeft;
      rectSel.y+=doc.scrollTop;
      rectSel.top+=doc.scrollTop;
      rectSel.bottom+=doc.scrollTop;
      
      rectSel.x=rectSel.left=Math.round(rectSel.x);
      rectSel.right=Math.round(rectSel.x);
      rectSel.y=rectSel.top=Math.round(rectSel.y);
      rectSel.bottom=Math.round(rectSel.bottom);
      
      if(range.startContainer==range.endContainer && range.startContainer.hasChildNodes() && range.endOffset==range.startOffset+1 && range.startContainer.childNodes[range.startOffset].rect)
      {
        rectSel=range.startContainer.childNodes[range.startOffset].rect;
      }
      selectParam.wordOcc=-1;
      selectParam.globalOcc=-1;
      selectParam.wordSelect=-1;
      if(currentSelection && selText=="")
      {
        contentSendMessageToPopup({action:"updateWordCount", wordSelect:selectParam.wordSelect, wordOcc:selectParam.wordOcc, globalOcc:selectParam.globalOcc, from:"content-script.js > event > selectionchange"});
        currentSelection=false;
      }

      //if(DBG) console.log("selectionchange> rect=", rectSel);
      //if(DBG) console.log("range changed", range);
    } 
  });

  // Listen for the message event from popup or background script
  chrome.runtime.onMessage.addListener(
    function (message, sender, sendResponse) {
      handleMessageContentScript(message);      
      sendResponse({received: "OK", globalOcc:selectParam.globalOcc});
    }
  );
  window.addEventListener('message', function (e) {
    // Get the sent data
    var message = e.data;
    handleMessageContentScript(message);
  });
} 

//needs multiFindWin & multiFindWinDiv
function handleMessageContentScript(message)
{
    askedForUpdatePopup=false;
    if(DBG) console.log("content-script received:", message);
    /*
    if (message.action === "doHighlight") {//obsolete
        //if(message.param==="from SW onActivated" || message.param==="from SW onFocusChanged" ) popupOn=false; else popupOn=true;
        if (typeof(message.height)!="undefined") multiFindWinDiv.style.height=(message.height+5)+"px";
        updateAllDocHighlightsWhenStabilized();
    }
    */
    if(message.action === "updateOptionsNew" || message.action === "updateHighlightsAndPopup")
    {
        if(!iframe) askedForUpdatePopup=true;
        updateAllDocHighlightsWhenStabilized(); 
        //contentSendMessageToPopup({action:"updatePopup", from:"content-script.js > handleMessageContentScript(updateHighlightsAndPopup)"});
    }
    
    if(!iframe) //main window
    {
        if (message.action === "requestClosePopup"  || popupOn && message.action=="requestTogglePopup") {
            //multiFindWinDiv.style.display="none";
            multiFindWinDiv.style.height="0px";
            message.action="confirmClosePopup";
        }
        if (!popupOn && message.action=="requestTogglePopup") {
            //multiFindWinDiv.style.display="block";
            message.action="confirmOpenPopup";
            contentSendMessageToPopup({action:"askForHeight"});
            contentSendMessageToBackground({action:"thereCanBeOnlyOne"});
            multiFindWin.focus();
        }            
        if (popupOn && message.action=="answerHeight") {
            multiFindWinDiv.style.height=(message.height)+"px";
            multiFindWinDiv.style.width=(message.width)+"px";
            //multiFindWin.contentDocument.body.style.height=(message.height+1)+"px";
            //multiFindWin.contentDocument.body.style.width=(message.width+1)+"px";
        }  
        if (message.action=="requestTranparency") {
            if(message.value)
                multiFindWinDiv.classList.add("HL-transparent");
            else
                multiFindWinDiv.classList.remove("HL-transparent");

        }  
        if(message.action === "moveSearch")
        {
            if(message.dir === "left")
            {
                multiFindWinDiv.style.left=scrollbarWidth+"px";
                multiFindWinDiv.style.right="auto";
            }
            if(message.dir === "right")
            {
                multiFindWinDiv.style.right=scrollbarWidth+"px";
                multiFindWinDiv.style.left="auto";
            }
            if(message.dir === "top")
            {
                multiFindWinDiv.style.top="0px";
                multiFindWinDiv.style.bottom="auto";
            }
            if(message.dir === "bottom")
            {
                multiFindWinDiv.style.bottom="0px";
                multiFindWinDiv.style.top="auto";
            }
        }        
        if(message.action === "moveScroll")
        {
            if(message.dir === "left")
            {
              scrollbarDiv.style.left = "0";     
              scrollbarDiv.style.right = "auto";     
              scrollbarDiv.style.transform = "scaleX(-1)";
              scrollbarButton.style.left = scrollbarWidth+"px";
              scrollbarButton.style.right = "auto";
              scrollbarButton.textContent = triRightChar; //"&blacktriangleright;"; 
            }
            if(message.dir === "right")
            {
              scrollbarDiv.style.right = "0";
              scrollbarDiv.style.left = "auto";
              scrollbarDiv.style.transform = "scaleX(1)";
              scrollbarButton.style.right = scrollbarWidth+"px";
              scrollbarButton.style.left = "auto";
              scrollbarButton.textContent = triLeftChar; //"&blacktriangleleft;";
            }
        }        
    }
    
    if (message.action === "giveFocus")
    {
      //isActiveElement=message.value;  //from background script
      isActiveElement = (focusID == message.focusID);  //from background script
      if(isActiveElement)
      {
        if(highlightActive /*|| popupOn*/) contentSendMessageToBackground({action:"updateBadge", number:selectParam.wordCount.reduce(function(a, b){return a + b;}, 0).toString()});
        contentSendMessageToPopup({action:"updateWordCount", wordCount:selectParam.wordCount, from:"content-script.js > drawScrollbar()"});
      }
      if (DBG) {if(isActiveElement) document.body.style.backgroundColor="#F8F8FF"; else document.body.style.backgroundColor="#E8E8EE";}
    }
    if (message.action === "confirmClosePopup")
    {
      popupOn=false; //it is important for an iframe to know if the popup is on or off in order to drow or not the scrollbar marks
      /*document.body.style.backgroundColor = "blue" ;*/
      //if(!iframe) multiFindWinDiv.style.height="0px";
      //if(!highlightActive) // highlighActive could have been changed via a command or the popup 
      updateAllDocHighlightsWhenStabilized();
      contentSendMessageToMyIframes(message);
    }
    if (message.action === "confirmOpenPopup") 
    {
      if(!iframe && !multiFindWin.src) multiFindWin.src=chrome.runtime.getURL("popup.html");
      popupOn=true; //it is important for an iframe to know if the popup is on or off in order to drow or not the scrollbar marks
      /*document.body.style.backgroundColor = "red" ;*/
      if(!iframe) if (typeof(message.height)!="undefined") multiFindWinDiv.style.height=(message.height+5)+"px";
      //if(!highlightActive) // highlighActive could have been changed via a command or the popup 
      updateAllDocHighlightsWhenStabilized();
      contentSendMessageToMyIframes(message);
    }
    /*
    if (message.action === "doToggle") {   //from background script
        var group  = message.group;
        var toggle = message.toggle;
        chrome.storage.local.get([group]).then((result)=>{
            result[group][toggle]=!result[group][toggle];
            chrome.storage.local.set({[group]:result[group]}).then(()=>{
                contentSendMessageToPopup({action:"updatePopup", from:"content-script.js > message > doToggle"});
                updateAllDocHighlightsWhenStabilized();
            });
        });            
    }
    */
    if(isActiveElement)
    {
        if (message.action === "addSelection") {
            
            addSelectedWordsToWordlist();
        }
        if (message.action === "addSimilarSelection") {
            addSimilarWordsToWordlist();
        }
        if (message.action === "doUp") {
            //if(DBG) console.log(iframe?"iFrame":"main window", "doUp");
            jumpTo(message.param, -1);
        }
        if (message.action === "doDown") {
            //if(DBG) console.log(iframe?"iFrame":"main window", "doDown");
            jumpTo(message.param, 1);
        }
        if (message.action === "requestWordCount") {
          //if(DBG) console.log(iframe?"iFrame":"main window", "requestWordCount");
          //if (window.getSelection().anchorNode===null)return;
          //if(!selectParam.wordCount)
          //{
          //  updateAllDocHighlightsWhenStabilized();
          //}
          //else
          {
            if(highlightActive /*|| popupOn*/) contentSendMessageToBackground({action:"updateBadge", number:selectParam.wordCount.reduce(function(a, b){return a + b;}, 0).toString()});
            contentSendMessageToPopup({action:"updateWordCount", wordCount:selectParam.wordCount, wordSelect:selectParam.wordSelect, wordOcc:selectParam.wordOcc, globalOcc:selectParam.globalOcc, from:"content-script.js > message > requestWordCount"});
          }
        }
     } 
    else // current frame does not have the focus
    {
        if ((message.action === "doUp" || message.action === "doDown") && message.from !== "sw.js > onCommand") contentSendMessageToMyIframes(message);
    }
    if(message.action === "updateWordCount" || message.action === "updateWordList") contentSendMessageToPopup(message);//forward the message 

}
function createPopup()
{
    if(DBG) console.log('Popup created');
    //iframe
    var iframe=document.createElement("iframe");
    iframe.title="advanced search";
    //NZO1509
    //iframe.src=chrome.runtime.getURL("popup.html");
    iframe.width="100%";
    iframe.height="100%";
    iframe.style.position="static";
    iframe.style.zIndex="100000";
    iframe.style.border="0"; //for Firefox
    iframe.frameBorder="none"; //"0"
    //iframe.style.background="white";
    iframe.name="multi-find-menu";
    //iframe.style.pointerEvents = 'auto'; 
    
    //div container, containing the iframe and buttons
    var div=document.createElement("div");
    div.className="multi-find-menu-container";
    div.onblur = function(){this.style.display="none"};
    div.style.width="400px";//chrome.i18n.getMessage("css_size");
    div.style.top = "0px";
    div.style.bottom="auto";
    div.style.right = scrollbarWidth+"px";
    div.style.left="auto";
    div.style.position = "fixed";
    div.style.height = "0px";
    div.style.display = "block"; 
    div.style.zIndex = 99998; // 1 less than scrollbar
    div.style.maxHeight = "100vh";
    //div.style.transition= "top 1s ease, left 1s ease, bottom 1s ease, right 1s ease";
    //div.style.pointerEvents = 'none';  //does not prevent clicking on whatever is under it
    div.style.overflow = "hidden";
        
    popupOn=false;    
    
    div.append(iframe);
    document.body.appendChild(div);
    
    iframe.onload = function() {

        //console.log("content-script (onload)", "document.body.clientWidth =", document.body.clientWidth, "document.body.clientHeight =", document.body.clientHeight);
        //console.log("content-script (onload)", "document.documentElement.clientWidth =", document.documentElement.clientWidth, "document.documentElement.clientHeight =", document.documentElement.clientHeight);
        //console.log("content-script (onload)", "window.innerWidth =", window.innerWidth, "window.innerHeight =", window.innerHeight);
        contentSendMessageToPopup({action:"webpageResize", width:document.documentElement.clientWidth-4, height:document.documentElement.clientHeight-4});
    };
    return [iframe, div];
}

//MAIN
if(document.readyState !== "complete" && document.readyState!=="interactive") {
  window.addEventListener("DOMContentLoaded", function (event){
    afterLoad();
  },false);
} else {
    afterLoad();
}
//to be modified word=(text, col)
function addSelectionToWordlist(textTab)
{
    var listOfNewWords=[];
    for(let i=0; i<textTab.length; i++)
    {
        textTab[i]=textTab[i].split('\n');
        for(let j=0; j<textTab[i].length; j++)
            listOfNewWords.push(textTab[i][j].trim()); //for Firefox (selection is not trimmed by default)
    }
    chrome.storage.local.get(["page"]).then((result)=>{
        var word=result.page.word;
        var colIndex=(word.length+colorOffset)%colorRange;
        listOfNewWords.forEach(oneWord => {if(oneWord && word.findIndex(a=>a.text===oneWord)==-1)  word.push({text:oneWord, on:true, colIndex});})
        result.page.word=word;
        chrome.storage.local.set({page:result.page}).then(()=>{
            //updateAllDocHighlightsWhenStabilized();
            contentSendMessageToPopup({action:"updateWordList", word});
        }); 
    });
}
function addSelectedWordsToWordlist() {
    let selTab=getSelection();
    var textTab=[];
    for(let i=0; i<selTab.rangeCount; i++) {
        textTab[i]=selTab.getRangeAt(i).toString();
    }
    addSelectionToWordlist(textTab);

}

function addSimilarWordsToWordlist() {
    const selection = window.getSelection();
    if (!selection.rangeCount) return; // no selection

    // Get the selected node and its parent
    const range = selection.getRangeAt(0);
    const selectedNode = range.startContainer;

    // Ensure that the selection covers an entire node (with possible trimming of white spaces)
    const selectedText = range.toString().trim();
    if (selectedNode.textContent.trim() !== selectedText) {
        // If selection is not an entire node, regular mode
        addSelectedWordsToWordlist();
        return;
    }

    // Traverse up the hierarchy to <body>, capturing the tag names and attributes
    const hierarchy = [];
    const initialElement = selectedNode.nodeType===Node.TEXT_NODE ? selectedNode.parentNode : selectedNode;
    let currentNode = initialElement;
    while (currentNode && currentNode.tagName !== 'BODY') {
        if(currentNode.tagName !== tagNameFound && currentNode.tagName !== tagNameDummy)
        hierarchy.push({
            tag: currentNode.tagName,
            class: currentNode.className, // or other identifying attributes
        });
        currentNode = currentNode.parentNode;
    }

    // Reverse the hierarchy so that we start from the top (body -> down to selected node)
    //hierarchy.reverse();

    // Find all nodes with the same tag and hierarchy
    // Get the tag and class of the parent node
    const parentTag = initialElement.tagName;
    //const parentClass = initialElement.className.trim();
    const parentClass = initialElement.className.trim().replace(/([!"#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\$1');

    // Modify the querySelectorAll to include the class if it exists
    let selector = parentTag;
    if (parentClass) {
        selector += '.' + parentClass.split(/\s+/).map(cls => cls.trim()).join('.');
    }

    const similarWords = [];
    document.querySelectorAll(selector).forEach(node => {
        let isSimilar = true;
        let nodeHierarchy = [];
        let parent = node;//.parentNode;

        // Traverse up and check the node hierarchy
        while (parent && parent.tagName !== 'BODY') {
            nodeHierarchy.push({
                tag: parent.tagName,
                class: parent.className,
            });
            parent = parent.parentNode;
        }

        // Reverse node hierarchy and compare with the selected node's hierarchy
        //nodeHierarchy.reverse();
        if (nodeHierarchy.length !== hierarchy.length) {
            isSimilar = false;
        } else {
            for (let i = 0; i < hierarchy.length; i++) {
                if (hierarchy[i].tag !== nodeHierarchy[i].tag || 
                    hierarchy[i].class !== nodeHierarchy[i].class) {
                    isSimilar = false;
                    break;
                }
            }
        }

        // If hierarchies match, add the text content of this node
        if (isSimilar) {
            similarWords.push(node.textContent.trim());
        }
    });

    // Add similar words to the word list
    addSelectionToWordlist(similarWords);
}

function contentSendMessageToBackground(message)
{
    if(DBG) console.log("content > contentSendMessageToPopup (", message, ")");
    chrome.runtime.sendMessage(message,
      function (response) {
        if (!chrome.runtime.lastError) {} else {}
      }
    );
}

//needs multiFindWin
function contentSendMessageToPopup(message)
{
    if(!iframe)
    {
      multiFindWin.contentWindow.postMessage(message, "*");
    }
    else
    {
      //message.from="iframe";
      window.parent.postMessage(message, "*");
    }
}

//needs multiFindWin
function contentSendMessageToMyIframes(message)
{
    for (let i = 0; i < window.frames.length; i++) { //forward message to all the other iframes
        if(iframe || window.frames[i] !== multiFindWin.contentWindow)  window.frames[i].postMessage(message, '*');
    }
}

function updateStyle(textarea)
{
  if(textarea.nextSibling && textarea.nextSibling.tagName===tagNameTextareaShort)
  {
    var fake=textarea.nextSibling;
    //fake.textContent = textarea.value; 
    makeFake(textarea, fake);
  }
}


function addCustomScrollbar()
{
  scrollbarParent=document.createElement("div");
  if(!scrollbarDiv) scrollbarDiv = document.createElement("div");
//  else if(DBG) console.log("error: custom scrollbar already exists");
  scrollbarDiv.style.position = "fixed";// absolute";
  scrollbarDiv.style.right = "0";
  scrollbarDiv.style.top = "0";
  scrollbarDiv.style.width = scrollbarWidth+"px"; // to be checked
  scrollbarDiv.style.height = "100%"; // maximum height
  scrollbarDiv.style.zIndex = 99999;   //on top of all
  scrollbarDiv.style.pointerEvents = 'none';  //does not prevent clicking on whatever is under it
  scrollbarParent.appendChild(scrollbarDiv);
  if(!scrollbarCanvas) scrollbarCanvas = document.createElement("CANVAS");
//  else if(DBG) console.log("error: canvas for scrollbar already exists");
  scrollbarCanvas.width=scrollbarWidth;
  scrollbarCanvas.height=scrollbarDiv.clientHeight;//1000
  scrollbarCanvas.ctx=scrollbarCanvas.getContext("2d");
  var myImage = scrollbarCanvas.toDataURL("image/png");  
  scrollbarDiv.style.backgroundImage = "url("+myImage+")";
  scrollbarDiv.style.backgroundSize = "100% 100%";
  scrollbarDiv.style.backgroundRepeat = "no-repeat";
  
  scrollbarButton= document.createElement("button");
  scrollbarButton.style.position = "fixed";// absolute";
  scrollbarButton.style.right = scrollbarWidth+"px";
  scrollbarButton.style.left = "auto";
  scrollbarButton.style.top = "50%";
  scrollbarButton.textContent = triLeftChar; //"&blacktriangleleft;";
  scrollbarButton.style.zIndex = 99999;   //on top of all
  scrollbarButton.className = "move-button";
  scrollbarButton.addEventListener("click", invertScrollbar);
  
  /*
    scrollbarButton.style.padding = "0"; 
    scrollbarButton.style.margin="-2px";
    scrollbarButton.style.cursor= "pointer";
    scrollbarButton.style.display= "flex";
    scrollbarButton.style.alignItems= "center";
    scrollbarButton.style.justifyContent= "center";
    scrollbarButton.style.pointerEvents= "auto"; 
    scrollbarButton.style.width="16px";
    scrollbarButton.style.height="16px";
    scrollbarButton.style.borderRadius= "8px";
*/
  
  
  scrollbarParent.appendChild(scrollbarButton);
  document.body.appendChild(scrollbarParent);
  
  if(highlightActive /*|| popupOn*/) drawScrollbarWhenStabilized(); //drawScrollbar();

  window.addEventListener('resize', resize);
}

function resize()
{
    drawScrollbarWhenStabilized();
    if(!iframe)
    {
        //console.log("---------------------------------");
        //console.log("content-script (on resize)", "document.body.clientWidth =", document.body.clientWidth, "document.body.clientHeight =", document.body.clientHeight);
        //console.log("content-script (on resize)", "document.documentElement.clientWidth =", document.documentElement.clientWidth, "document.documentElement.clientHeight =", document.documentElement.clientHeight);
        //console.log("content-script (on resize)", "window.innerWidth =", window.innerWidth, "window.innerHeight =", window.innerHeight);
        contentSendMessageToPopup({action:"webpageResize", width:document.documentElement.clientWidth-4, height:document.documentElement.clientHeight-4});

    } 
}

function invertScrollbar()
{
    if(scrollbarButton.textContent == triLeftChar)
    {
      scrollbarDiv.style.left = "0";     
      scrollbarDiv.style.right = "auto";     
      scrollbarDiv.style.transform = "scaleX(-1)";
      scrollbarButton.style.left = scrollbarWidth+"px";
      scrollbarButton.style.right = "auto";
      scrollbarButton.textContent = triRightChar; //"&blacktriangleright;"; 
    }
    else
    {
      scrollbarDiv.style.right = "0";
      scrollbarDiv.style.left = "auto";
      scrollbarDiv.style.transform = "scaleX(1)";
      scrollbarButton.style.right = scrollbarWidth+"px";
      scrollbarButton.style.left = "auto";
      scrollbarButton.textContent = triLeftChar; //"&blacktriangleleft;";
    }
}

function updateAllDocHighlightsWhenStabilized()
{
    clearTimeout(updateAllDocTimeout);
    updateAllDocTimeout = setTimeout(() => {
      updateAllDocHighlights();
    }, 100);
}

function drawScrollbarWhenStabilized()
{
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
      drawScrollbar();
    }, 100);
}

function spanComp(a,b)
{
  var comp=a.rect.top+a.rect.bottom!=b.rect.top+b.rect.bottom ? (a.rect.top+a.rect.bottom)-(b.rect.top+b.rect.bottom) : (a.rect.left+a.rect.right)-(b.rect.left+b.rect.right)
//  if(DBG) console.log(a.rect, b.rect, "comp:",comp);
  return comp;
}

function findPosition(element) {
    var x = 0, y = 0;
    var width = element.offsetWidth;
    var height = element.offsetHeight;
    do {
        x += (element.offsetLeft || 0);
        y += (element.offsetTop  || 0);
        element = element.offsetParent;
    } while(element);

    return {x:x, left:x, right:x+width, y:y, top:y, bottom:y+height, width:width, height:height};
}

function scrollParentToShowChildWithMargin(parent, elementRect, scrollMargin) {
  let sX = parent.scrollLeft;
  let sY = parent.scrollTop;
  
  var parentRect=findPosition(parent);

  if (elementRect.left < -parentRect.left + parent.scrollLeft) {sX = -parentRect.left + elementRect.left - scrollMargin;}
  if (elementRect.right >  -parentRect.left + parent.scrollLeft + parent.clientWidth) {sX = -parentRect.left + elementRect.right - parent.clientWidth + scrollMargin;}
  if (elementRect.top <  -parentRect.top + parent.scrollTop) {sY = -parentRect.top + elementRect.top - scrollMargin;}
  if (elementRect.bottom > -parentRect.top + parent.scrollTop + parent.clientHeight) {sY = -parentRect.top + elementRect.bottom - parent.clientHeight + scrollMargin;}

  if (sX < 0) {sX = 0;}
  if (sX > parent.scrollWidth - parent.clientWidth) {sX = parent.scrollWidth - parent.clientWidth;}
  if (sY < 0) {sY = 0;}
  if (sY > parent.scrollHeight - parent.clientHeight) {sY = parent.scrollHeight - parent.clientHeight;}

  if (sX != parent.scrollLeft || sY != parent.scrollTop) {
    //if(DBG) console.log("sY:", sY, "sX", sX, "scrollTop:", parent.scrollTop, "scrollLeft:", parent.scrollLeft, "clientHeight:", parent.clientHeight, "clientWidth:", parent.clientWidth, "scrollHeight:", parent.scrollHeight, "scrollWidth:", parent.scrollWidth);
    parent.scrollTo({top:sY, left:sX, behavior:"smooth"});
    //if(DBG) console.log("sY:", sY, "sX", sX, "scrollTop:", parent.scrollTop, "scrollLeft:", parent.scrollLeft, "clientHeight:", parent.clientHeight, "clientWidth:", parent.clientWidth, "scrollHeight:", parent.scrollHeight, "scrollWidth:", parent.scrollWidth);
    }
  elementRect.left-=parent.scrollLeft;    
  elementRect.right-=parent.scrollLeft;    
  elementRect.top-=parent.scrollTop;    
  elementRect.bottom-=parent.scrollTop;    

}

function scrollToElement(element, scrollMargin) {
  let parent = element.parentNode; 
  var elementRect=findPosition(element);
  while (parent != null) {
    if (parent.scrollHeight > parent.clientHeight || parent.scrollWidth > parent.clientWidth) {
      scrollParentToShowChildWithMargin(parent, elementRect, scrollMargin);
    }
    parent = parent.parentNode;
  } 
}

function selectTag(tag)
{
//  if(DBG) console.log("selectTag(tag)", tag.rect);
    var range = new Range();
    range.setStartBefore(tag); 
    range.setEndAfter(tag);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);      
    //scrollToSelection(tag);
    scrollToElement(tag, 100);
    //scrollParentToShowChildWithMargin(document.scrollingElement, tag.rect, 100);
}

//return the index of where the element would be inserted in the sortedArray, an array sorted with cmpFunct
function binarySearch(element, sortedArray, cmpFunct)
{
//if(DBG) console.log("binarySearch> element - top", element.rect.top, "bottom", element.rect.bottom, "left", element.rect.left, "right", element.rect.right);
  let beg = 0;
  let end = sortedArray.length - 1;
  while (beg <= end)
  {
    let mid = Math.floor((beg + end) / 2);
    let comparison = cmpFunct(element, sortedArray[mid]);
    if (comparison < 0) end = mid - 1;
    else if (comparison > 0) beg = mid + 1;
    else
    {
//    if(DBG) console.log("binarySearch> index", mid, "found", true);
      return {index:mid, found:true};
    }
  }
// if(DBG) console.log("binarySearch> index", beg, "found", false);
  return {index:beg, found:false};
}

var globalOcc=-1;
//n=-1 of general jump, n>=0 if a particular word is searched
//search begins at globalOcc index 
function jumpTo(n, dir)
{
  //if (window.location !== window.parent.location) return; //iFrame
  //if (window.getSelection().anchorNode===null) return;
  //else if(DBG) console.log("jumpTo", window.location !== window.parent.location, window.getSelection());
  
  //var allSpans = document.querySelectorAll(tagName+'[className^="HL-style-"]');
  var allSpans = document.querySelectorAll(tagNameFound);
  
  if(allSpans.length)
  { 
    var allSpansArr = Array.prototype.slice.call(allSpans, 0);  //from nodeList to array
    allSpansArr.sort(spanComp);
    allSpansArr=allSpansArr.filter(a=>a.rect.width!==0);
    var binSearch = binarySearch({rect:rectSel}, allSpansArr, spanComp);
    globalOcc = binSearch.index;
    if(n==-1)//general jump
    {
      if (dir==-1||binSearch.found) globalOcc=globalOcc+dir;
      globalOcc=(globalOcc+allSpansArr.length)%allSpansArr.length;

      var span = allSpansArr[globalOcc];
      
      currentSelection=true;
      selectTag(span);
      var wordSelect=span.getAttribute("HL-word");
      var spanArray=allSpansArr.filter(a=>a.getAttribute("HL-word")==wordSelect);
      var wordOcc=spanArray.indexOf(span);
      selectParam.wordSelect=wordSelect;
      selectParam.wordOcc=wordOcc;
      selectParam.globalOcc=globalOcc;
      if(isActiveElement) contentSendMessageToPopup({action:"updateWordCount", wordSelect:selectParam.wordSelect, wordOcc:selectParam.wordOcc, globalOcc:selectParam.globalOcc, from:"content-script.js > jumpTo(n==-1)"});
    }
    else // n!=-1: we are jumping the the next word of a particular line of the inputbox
    {
      var wordSelect=n;
      var wordOcc=-1;
      var spanArray=allSpansArr.filter(a=>a.getAttribute("HL-word")==wordSelect);
      if (dir==-1||binSearch.found) globalOcc=globalOcc+dir;
      globalOcc=(globalOcc+allSpansArr.length)%allSpansArr.length;
      if(spanArray.length)
      {
        currentSelection=true;
        wordOcc = spanArray.indexOf(allSpansArr[globalOcc])
        while(wordOcc==-1)
        {
           globalOcc+=dir;
           globalOcc=(globalOcc+allSpansArr.length)%allSpansArr.length;
           wordOcc = spanArray.indexOf(allSpansArr[globalOcc]);
        }
        var span = allSpansArr[globalOcc];       
        selectTag(span);
        selectParam.wordSelect=wordSelect;
        selectParam.wordOcc=wordOcc;
        selectParam.globalOcc=globalOcc;
        if(isActiveElement) contentSendMessageToPopup({action:"updateWordCount", wordSelect:selectParam.wordSelect, wordOcc:selectParam.wordOcc, globalOcc:selectParam.globalOcc, from:"content-script.js > jumpTo(n!=-1)"});
      }
    }    
  }  
}

function updateAllDocHighlights()
{
  chrome.storage.local.get(["page", "display", "search"]).then((result)=>{
    word=result.page.word;
    highlightActive=result.display.highlightActive;
    maj=result.search.maj;
    diac=result.search.diac;
    oneChar=result.search.oneChar;
    scrollActive=result.display.scrollActive;
    counterOn=result.display.counterOn;
    //NZO !!! popupOn=result.display.popupOn;
    darkMode=result.display.darkMode;
    darkTheme[1] = window.matchMedia('(prefers-color-scheme: dark)').matches ? darkTheme[2] : darkTheme[0]; 
    colorOffset =  result.display.colorOffset;
    colorRange  =  result.display.colorRange;
    unicode=true;
    loc=result.search.loc;
    //tagStyle=result.display.style?'HL-glow-':'HL-shadow-';
    highlightStyle=result.display.style;
    highlightColor=result.display.highlightColor;
    updateAllDocHighlights2(word, highlightActive, highlightColor, maj, diac, scrollActive, counterOn, darkMode, popupOn, unicode, loc);
  });
}
function updateAllDocHighlights2(word, highlightActive, highlightColor, maj, diac, scrollActive, counterOn, darkMode, popupOn, unicode, loc)
{
    var orderedWord=[];
    
    //for(var i=0; i<word.length;i++) if(word[i].on) orderedWord.push({text:word[i].text , originalIndex:i});
    //NZO pipe support v1
    //perhaps no need to calculate that if the input box has not been modified
    for(var i=0; i<word.length;i++) if(word[i].on) 
    {
        var wordTab=word[i].text.split(orSeparator);
        wordTab.forEach(oneWord => {if(oneWord && orderedWord.findIndex(a=>a.text===oneWord)==-1)  orderedWord.push({text:oneWord, originalIndex:i});} );
    }
    
    orderedWord.sort((a,b)=>b.text.length-a.text.length);
    
    wordRegex=[];
    //for(let i=0; i<word.length; i++) wordRegex[i]=wordToSearch(word[i], maj, diac, unicode, loc);
    for(let i=0; i<orderedWord.length; i++) wordRegex[i]={text:wordToSearch(orderedWord[i].text, maj, diac, unicode, loc), originalIndex:orderedWord[i].originalIndex};
    //main document
    removeAllHighlights();
    var elements = [document.body];
    if(highlightActive /*|| popupOn*/)
    {
      var sel= window.getSelection();
      var range = sel.rangeCount? sel.getRangeAt(0):null;
      //if(DBG) console.log("highlightElementRec from updateAllDocHighlights")
      var t0=Date.now();
      for (var i = 0; i < elements.length; i++) highlightElementRec(elements[i], wordRegex, range);
      var t1=Date.now();
      //if(DBG) console.log("updateAllDocHighlights > highlightElementRec >",t1-t0);
      drawScrollbarWhenStabilized(); //drawScrollbar();
      var t2=Date.now();
      //if(DBG) console.log("updateAllDocHighlights > drawScrollbar >",t2-t1);  
    }
    else
    {
        scrollbarButton.style.display="none";
        //if(isActiveElement) contentSendMessageToBackground({action:"updateBadge", number:""});
        if(isActiveElement) {
            var wordCount=new Array(word.length).fill(0);
            selectParam.wordCount=wordCount;
            
            contentSendMessageToBackground({action:"updateBadge", number:selectParam.wordCount.reduce(function(a, b){return a + b;}, 0).toString()});
            if(askedForUpdatePopup)
                contentSendMessageToPopup({action:"updatePopup", wordCount:selectParam.wordCount, from:"content-script.js > drawScrollbar()"});
            else
                contentSendMessageToPopup({action:"updateWordCount", wordCount:selectParam.wordCount, from:"content-script.js > drawScrollbar()"});
        }
    }
}

function wordToSearch(wrd, maj, diac, unicode, loc)
{
    if(wrd=="" || wrd=="\n" || wrd==" " || (!oneChar && wrd.length==1)) return "";
    var search=escapeRegex(wrd);  
    if(!diac) search=removeDiacritic3(search);
    if(unicode)
    {
        var bordLeft  = "(?<![\\p{L}\\p{N}_])";
        var bordRight = "(?![\\p{L}\\p{N}_])";
    }
    else
    {
        var bordLeft  = "(?<!\\w)";
        var bordRight = "(?!\\w)";
    }
//    var regexAlphaNum=RegExp("[\\p{L}\\p{N}_]", "u");
    if((loc==0||loc==1)&&search.slice(0,1).search(regexAlphaNum)==0) search = bordLeft + search;
    if((loc==0||loc==3)&&search.slice(-1 ).search(regexAlphaNum)==0) search = search   + bordRight;
    var modifier="";
    modifier+= maj?"":"i";
    modifier+= unicode?"u":"";
    
    var regex=RegExp(search, modifier);
    return regex;
}

var rangeTA=null;
var oldRange=null;
function textTextareaChange(_this, e)
{
  var textarea=_this;
  var fake = textarea.nextSibling;

  fake.textContent = textarea.value; 
  var index0 = textarea.selectionStart;
  var index1 = textarea.selectionEnd;
  oldRange={element:textarea, start:index0, end:index1};
  addSelection(fake, oldRange);
  highlightElementRec(fake, wordRegex, rangeTA); 
}

function insertOneSelection(parent, child, text, index0, index1)
{
  var textBefore  = text.slice(0, index0);
  var textBetween = text.slice(index0, index1);
  var textAfter   = text.slice(index1);
  var frag=document.createDocumentFragment();
  
  if(textBefore) frag.appendChild(document.createTextNode(textBefore));
  var select=document.createElement("SPAN");
  if(textBetween)
  {
    select.classList.add("HL-select");
    select.appendChild(document.createTextNode(textBetween));
  }
  else
  {
    select.classList.add("HL-caret"); select.style.backgroundColor=parent.style.color;
  }
  frag.appendChild(select);
  if(textAfter) frag.appendChild(document.createTextNode(textAfter));
  parent.replaceChild(frag,child);  
}

function addSelection(el, range)
{
  observer.disconnect();
  var index0=range.start;
  var index1=range.end;
  var offset=0;
  var parent;
  var child;
  var text;
  var len;
  var totalLen=el.innerText.length;
  var node=el.firstChild;
  var nextNode;
  while(node)
  {
    nextNode=node.nextSibling;
    if(node.nodeType === Node.TEXT_NODE || node.nodeType === Node.ELEMENT_NODE)//should be always true
    {
      if(node.nodeType === Node.TEXT_NODE){
        parent=el;
        child=node;
      } else if(node.nodeType === Node.ELEMENT_NODE) {
        parent=node;
        child=node.firstChild;
      }
      text=child.nodeValue;
      len=text.length;
      
      if(index0<offset+len && index1>offset || index0==index1 && index0==offset || index0==index1 && index0==totalLen && offset+len==totalLen) insertOneSelection(parent, child, text, Math.max(0, index0-offset), Math.min(index1-offset, len));
      /*
      if(index0>=offset && index1<=offset+len) insertOneSelection(parent, child, text, index0-offset, index1-offset);
      else
      if(index0>=offset && index0<=offset+len) insertOneSelection(parent, child, text, index0-offset, len);
      else
      if(index1>=offset && index1<=offset+len) insertOneSelection(parent, child, text, 0, index1-offset);
      else
      if(index0<offset  && index1>offset+len)  insertOneSelection(parent, child, text, 0, len);
      */
      //insertOneSelection(parent, child, text, Math.max(index0 - offset, 0), Math.min(index1 - offset, len));
      offset+=len;
      node=nextNode;
    }
  }
  observer.observe(document.body, { characterData: true, childList: true, subtree: true }); 
}

function selectTextareaChange(_this, e)
{
  if(e.buttons&1===0) return;
  var textarea=_this;
  var fake = textarea.nextSibling;
  //var el=this.firstChild.nextSibling;
  var index0 = textarea.selectionStart;
  var index1 = textarea.selectionEnd;
  //if(DBG) console.log("mousemove", index0, index1);
  if(!oldRange || oldRange.element!=textarea || oldRange.start!=index0 || oldRange.end!=index1)
  {
    fake.textContent = textarea.value; 
    highlightElementRec(fake, wordRegex, null);
    oldRange={element:textarea, start:index0, end:index1};
    addSelection(fake, oldRange);
  }
}

function selectTextareaChange2(_this, e)
{
  //if(e.buttons&1===0) return;
  var textarea=_this;
  var fake = textarea.nextSibling;
  //var el=this.firstChild.nextSibling;
  var index0 = textarea.selectionStart;
  var index1 = textarea.selectionEnd;
  //if(DBG) console.log("click", index0, index1);
  if(!oldRange || oldRange.element!=textarea || oldRange.start!=index0 || oldRange.end!=index1)
  {
    fake.textContent = textarea.value; 
    highlightElementRec(fake, wordRegex, null);
    oldRange={element:textarea, start:index0, end:index1};
    addSelection(fake, oldRange);
  }
}


function makeFake_old(sourceNode, targetNode) {

  //targetNode.innerHTML = sourceNode.value;
  
  const computedStyle = window.getComputedStyle(sourceNode);
  Array.from(computedStyle).forEach(key => targetNode.style.setProperty(key, computedStyle.getPropertyValue(key), computedStyle.getPropertyPriority(key)));

  targetNode.style.position="absolute";
  targetNode.style.pointerEvents = 'none';
  targetNode.style.top="0";
  //targetNode.style.top=targetNode.style.height;
  targetNode.style.left="0"; //"300px";
  //targetNode.style.width="100%";
  //targetNode.style.height="100%";
  targetNode.contentEditable="true";
  targetNode.style.whiteSpace="pre-wrap";
  if(sourceNode.tagName==="INPUT") targetNode.style.wordBreak="break-all";
  targetNode.style.overflowWrap="anywhere";
  //targetNode.style.lineBreak="anywhere";
}

function makeFake(sourceNode, targetNode) {

  //targetNode.innerHTML = sourceNode.value;
  
  //var newNode=sourceNode.cloneNone();
  const computedStyle = window.getComputedStyle(sourceNode);
  Array.from(computedStyle).forEach(key => targetNode.style.setProperty(key, computedStyle.getPropertyValue(key), computedStyle.getPropertyPriority(key)));

  targetNode.style.position="absolute";
  targetNode.style.pointerEvents = 'none';
  //targetNode.style.top="0";
  targetNode.style.top=(+(targetNode.style.height.slice(0,-2))+10)+"px";
  targetNode.style.left="0"; //"300px";
  //targetNode.style.width="100%";
  //targetNode.style.height="100%";
  targetNode.contentEditable="true";
  targetNode.style.whiteSpace="pre-wrap";
  if(sourceNode.tagName==="INPUT") targetNode.style.wordBreak="break-all";
  targetNode.style.overflowWrap="anywhere";
  //targetNode.style.lineBreak="anywhere";
}

var INPUT=false;

function highlightElementRec(element, wordRegex, range)
{
  if(!element) return;  //element can be null
  
  var nodeType=element.nodeType;
  if(nodeType !== Node.TEXT_NODE && nodeType !== Node.ELEMENT_NODE) return;
  if(nodeType === Node.TEXT_NODE)
  {
    if(element.parentNode) element=element.parentNode; else return;
  }
  var tagName=element.tagName;
  if( (!INPUT && tagName==="TEXTAREA") || tagName==="STYLE" || tagName==="SCRIPT" || tagName==="NOSCRIPT" || tagName==="AUDIO" || tagName==="VIDEO" || tagName==="OBJECT" || tagName==="IFRAME") return; 
  if(tagName.slice(0,tagNameFoundShort.length)==tagNameFoundShort) return;    //must include tagNameDummy ? I don't think so
  if(!element.textContent && !(tagName==="INPUT" && (element.type==="text" || element.type==="search" || element.type==="button" || element.type==="password") )) return;
//                    ^
//                    | 
// bcp de temps ici --J  
  
  if(INPUT && (tagName==="TEXTAREA" || (tagName==="INPUT" && (element.type==="text" || element.type==="search" || element.type==="button" || element.type==="password") )))
  {
    var textarea = element;
    if(textarea.nextSibling && textarea.nextSibling.tagName===tagNameTextareaShort)
    {
      var fake=textarea.nextSibling;
      fake.textContent = textarea.value; 
      //makeFake(textarea, fake);
      element=fake;
    }
    else
    {
      var dum = document.createElement(tagNameTextareaDummyShort);
      dum.style.position="relative";
      dum.style.display="inline-block";
      
      var fake=document.createElement(tagNameTextareaShort);
      fake.textContent = textarea.value; 
      makeFake(textarea, fake);
     
      textarea.parentNode.insertBefore(dum,textarea.nextSibling); 
      dum.appendChild(textarea);
      dum.appendChild(fake);   
       
      //use textarea not element as _this parameter for text/selectTextareaChange, because element will be modified
      textarea.addEventListener("input",      function(e) {setTimeout(function () {textTextareaChange   (textarea, e)})});
      textarea.addEventListener("mousemove",  function(e) {setTimeout(function () {selectTextareaChange (textarea, e)})});
      textarea.addEventListener("click",      function(e) {setTimeout(function () {selectTextareaChange2(textarea, e)})});
      textarea.addEventListener("keydown",    function(e) {setTimeout(function () {selectTextareaChange2(textarea, e)})});
      textarea.addEventListener("focus",      function(e) {updateStyle(this)});
      textarea.addEventListener("blur",       function(e) {updateStyle(this)});
      textarea.addEventListener("mouseup",    function(e) {updateStyle(this)});
      textarea.addEventListener("mousedown",  function(e) {updateStyle(this)});
      return;           //fake is the nextSibling: it will be treated automatically
      //element=fake;
    }
  } 
  
  var style = window.getComputedStyle(element);    // most of the time is spend here
  //var style = element.style;
  // Check if the element is not a span with the class "HL-style-*" and if it's not hidden or set to display:none
  var style_display=style.display;
  if (
    style.visibility === "hidden"
    || style_display === "none"
    //|| style.opacity === "0"  //removed because problem with elements that appear progressively
    || style.clip === "rect(1px 1px 1px 1px)"
  ) return;
  
  // Get the first child of the current element
  var child = element.firstChild;
  while(child)
  {    
    // Check if the child is a text node
    if (child.nodeType === Node.TEXT_NODE)
    {
       child=highlightTextNode(child, wordRegex, style_display, range);
    }
    else
    {
      highlightElementRec(child, wordRegex, range); // recursive call
      child=child.nextSibling; 
    }
  }
}

function escapeRegex(str) {
    return str.replace(/\u00a0/gu, " ").replace(/[\\^$*+?.()|{}[\]]/gu, '\\$&'); // $& means the whole matched string
    //return str;
}
/*
function removeDiacritic(str) {
  //return str.normalize("NFD").replace(/\p{Diacritic}/gu, '');
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, '');
  
}
*/

function removeDiacritic(str) {
  const diacriticMap = {
    'Đ': 'D', 'đ': 'd',
    'Ć': 'C', 'ć': 'c',
    'Č': 'C', 'č': 'c',
    'Ą': 'A', 'ą': 'a',
    'Ę': 'E', 'ę': 'e',
    'Ł': 'L', 'ł': 'l',
    'Ń': 'N', 'ń': 'n',
    'Ś': 'S', 'ś': 's',
    'Ź': 'Z', 'ź': 'z',
    'Ż': 'Z', 'ż': 'z'
  };

  return str.normalize("NFD")
            .replace(/[\u0300-\u036f]/g, '') // Remove diacritical marks
            .replace(/./gu, char => diacriticMap[char] || char); // Replace specific characters
}

function removeDiacritic3(str) {
  const diacriticMap = {
    'Đ': 'D', 'đ': 'd',
    'Ć': 'C', 'ć': 'c',
    'Č': 'C', 'č': 'c',
    'Ą': 'A', 'ą': 'a',
    'Ę': 'E', 'ę': 'e',
    'Ł': 'L', 'ł': 'l',
    'Ń': 'N', 'ń': 'n',
    'Ś': 'S', 'ś': 's',
    'Ź': 'Z', 'ź': 'z',
    'Ż': 'Z', 'ż': 'z'
  };

return str.normalize("NFD").replace(/[\u0300-\u036f]|[ĐđĆćČčĄąĘęŁłŃńŚśŹźŻż]/g, char => diacriticMap[char] || '');
}

function condensateDiacritic(str) {
  return str.normalize("NFC");
}

var isNode = (node, name) => node!==null && node.nodeName===name;

function createHighlighElement(wordIndex, colIndex, HLon, loc)
{
    var theme;
    if(darkMode==0) theme=0;
    if(darkMode==2) theme=1;
    if(darkMode==1) theme= darkTheme[1]==darkTheme[2]?1:0;
    var span = document.createElement(tagNameFound);
//    span.className=(tagStyle+((colIndex%colorRange+colorOffset)%colorMax))+" "+(tagRound+loc)+" "+(darkTheme[darkMode]);
    span.className=(tagRound+loc)+" "+(darkTheme[darkMode]);
    span.setAttribute("HL-word", wordIndex);
    span.setAttribute("title", chrome.i18n.getMessage("tip_highlighted"));// "highlighted by Multi Find");
    if(HLon && highlightStyle!==2)
    {
        span.style.backgroundColor=highlightColor[theme][colIndex].back;
        span.style.color=highlightColor[theme][colIndex].front;
        //if(tagStyle==="HL-glow-") span.style.boxShadow= "0 0 0.5em 0.1em "+highlightColor[theme][colIndex].back+", 0.1em 0.2em 0.2em 0em #0004";
        if(highlightStyle===1) span.style.boxShadow= "0 0 0.5em 0.1em "+highlightColor[theme][colIndex].back+", 0.1em 0.2em 0.2em 0em #0004";
    }
    return span;
}

//parent node, child node, text of child node, offset of searched string in text, length of searched string, row of searched string in input box, location of search
function addOneHighlight(parent, child, text, index, len, wordIndex, colIndex, HLon, loc, range)
{ 
    var startContainer1, startOffset1, endContainer1, endOffset1; //was missing! 
     // Split the text of the current child into text before the keyword, the keyword itself, and text after the keyword
    var textBefore = text.substring(0, index);
    var textBetween= text.substring(index, index + len);//to keep the initial capitalisation
    var textAfter = text.substring(index + len);
    
    var span0=document.createDocumentFragment();
    
    var next=null;        
    // If there is text before the keyword, create a new text node with that text and insert it before the current child
    if (textBefore) {
      var nodeBefore=document.createTextNode(textBefore);
      span0.appendChild(nodeBefore);  
      next=nodeBefore;
    }
    
    var span = createHighlighElement(wordIndex, colIndex, HLon, loc);

    var nodeBetween=document.createTextNode(textBetween);
    span.appendChild(nodeBetween);
    span0.appendChild(span);
    //var rect = span.getBoundingClientRect();
    //inserts the text after the keyword as a new text node
    if (textAfter) {
      var nodeAfter=document.createTextNode(textAfter);
      span0.appendChild(nodeAfter);
      if(!next) next=nodeAfter;
    }

    var change0=false;
    var change1=false;
    if(range)
    {
      if(range.startContainer==child)
      {
        if(range.startOffset<index)
        {
           startContainer1=nodeBefore;
           startOffset1=range.startOffset;
        }
        else
        if(range.startOffset>index+len)
        {
           startContainer1=nodeAfter;
           startOffset1=range.startOffset;
           if(textBefore) startOffset1-=textBefore.length;
           startOffset1-=textBetween.length;       
        }
        else
        {
           startContainer1=nodeBetween
           startOffset1=range.startOffset;
           if(textBefore) startOffset1-=textBefore.length;   
        }
        change0=true;
      }
      if(range.endContainer==child)
      {
        if(range.endOffset<index)
        {
           endContainer1=nodeBefore;
           endOffset1=range.endOffset;
        }
        else
        if(range.endOffset>index+len)
        {
           endContainer1=nodeAfter;
           endOffset1=range.endOffset;
           if(textBefore) endOffset1-=textBefore.length;
           endOffset1-=textBetween.length;       
        }
        else
        {
           endContainer1=nodeBetween
           endOffset1=range.endOffset;
           if(textBefore) endOffset1-=textBefore.length;   
        }
        change1=true;
      }
    }

    parent.replaceChild(span0, child); //removes the original text node
    /* 
    if(!span.nextSibling)
    {
      var br=document.createElement("BR");
      parent.appendChild(br);
    }
    */
    if(change0 || change1)
    {
      //if(DBG) console.log("1) addOneHighlight", range);
      if(change0) range.setStart(startContainer1, startOffset1); 
      if(change1) range.setEnd(endContainer1, endOffset1); 
      //const selection = window.getSelection();
      //selection.removeAllRanges();
      //selection.addRange(range);
      //if(DBG) console.log("2) addOneHighlight", range, endContainer1.nextSibling);
    }    
    if(!next) next=span.nextSibling;
        
    return next;
}

function insertDummy(text, child, parent, range)
{
    var span = document.createElement(tagNameDummy);
    var nodeUnder=document.createTextNode(text);
    span.appendChild(nodeUnder); 
    var change0=false;
    var change1=false;
    var startContainer1, startOffset1, endContainer1, endOffset1;
    if(range)
    {
        if(range.startContainer==child)
        {
            startContainer1=nodeUnder;
            startOffset1=range.startOffset;
            change0=true;
        }
        if(range.endContainer==child)
        {
            endContainer1=nodeUnder;
            endOffset1=range.endOffset;
            change1=true;
        }
    }
    parent.replaceChild(span, child);
    if(change0 || change1)
    {
      if(change0) range.setStart(startContainer1, startOffset1); 
      if(change1) range.setEnd(endContainer1, endOffset1); 
    }
    parent=span;
    child=nodeUnder;
    return [child, parent];
}

const regexAlphaNum=RegExp("[\\p{L}\\p{N}_]", "u");

function highlightTextNode(child, wordRegex, style_display, range)
{
  var text = child.nodeValue; //child.nodeValue is 5 to 6 times faster than child.textContent

  var parent = child.parentNode;
  //var doc=child.ownerDocument;
  //var prevHighlight= isNode(child.previousSibling, tagName) && child.previousSibling.className.includes("HL-"); 
  //var nextHighlight= isNode(child.nextSibling, tagName) && child.nextSibling.className.includes("HL-"); 
  var prevHighlight= isNode(child.previousSibling, tagNameFound); 
  var nextHighlight= isNode(child.nextSibling, tagNameFound); 
  //if(DBG) console.log(parent.tagName, text) ;
  var found=false;
  // Iterate through all words passed as the second parameter
  if(wordRegex) for(var j=0; !found && j<wordRegex.length; j++) //if(wordRegex[j].text!=="")
  {
      if(wordRegex[j].text==="") continue;
      
      var arr = !diac ? wordRegex[j].text.exec(removeDiacritic3(text)) : wordRegex[j].text.exec(text);
      
      if(arr && !(arr.index==0 && prevHighlight && (loc==0||loc==1)) && !(arr.index+arr[0].length==text.length && nextHighlight && (loc==0||loc==3)))
      {
          var keyword=arr[0];
          var index=arr.index;
          //var style = window.getComputedStyle(parent);  //in parameter now
          //to deal with Flexboxes: do it always?
          if(style_display==="flex" ||
          style_display==="inline-flex")
          { 
            //if(parent.tagName!=tagName)
            if(parent.tagName.slice(0, tagNameDummyShort.length)!=tagNameDummyShort)
                [child, parent] = insertDummy(text, child, parent, range);
          }
          
          found=true;
          
          child = addOneHighlight(parent, child, condensateDiacritic(text), index, keyword.length, wordRegex[j].originalIndex, word[wordRegex[j].originalIndex].colIndex, word[wordRegex[j].originalIndex].on, loc, range); 
          //child = addOneHighlight(parent, child, condensateDiacritic(text), index, keyword.length, wordRegex[j].originalIndex, loc, range); 
      }
  }
  if(!found) child=child.nextSibling;  //textNode, but no string found
  return child;
}

var coeffC=17;

function drawOneMarker(span, wordCount, i)    // i for debug only
{
  
  var height=scrollbarCanvas.height;
  //if(DBG) console.log("drawOneMarker");
  var col=span.getAttribute("HL-word"); //useless with the use of tagNameDummy
  var theme=span.classList.contains("HL-dark-theme") ? 1 : 0; //useless with the use of tagNameDummy
  if(col!==null)
  {
    //var doc = document.documentElement;//or document.scrollingElement ? 
    var doc = document.scrollingElement;
    
    var rect=findPosition(span);
    //var rect=getElementRect(span);
    
    span.rect=rect;
    //if(DBG) console.log("rect1", i, rect);

    if(span.rect.width!==0)
    {
      /*if(word[col].on)*/ wordCount[col]++;
      if(scrollActive /*&& word[col].on*/)
      {
        var colIndex=word[col].colIndex;
        var y   = (rect.top+rect.bottom)/2     / doc.scrollHeight;
        var x  = (rect.left+rect.right)/2    / doc.scrollWidth;
        //if(DBG) console.log("beg:", beg, "end:", end, "doc.scrollHeight:", doc.scrollHeight, "window.innerHeight:", window.innerHeight);
  
        scrollbarCanvas.ctx.fillStyle = highlightColor[theme][colIndex].back;
        scrollbarCanvas.ctx.strokeStyle = lineColor[theme];
        //scrollbarCanvas.ctx.strokeStyle = highlightColor[theme][colIndex].front;
  
        scrollbarCanvas.ctx.beginPath();
  
        scrollbarCanvas.ctx.moveTo(x*(scrollbarWidth-9),   y*(height-2*coeffC)+coeffC);
        scrollbarCanvas.ctx.lineTo(x*(scrollbarWidth-9)+9, y*(height-2*coeffC)+coeffC-5);
        scrollbarCanvas.ctx.lineTo(x*(scrollbarWidth-9)+9, y*(height-2*coeffC)+coeffC+5);
        scrollbarCanvas.ctx.closePath();
        scrollbarCanvas.ctx.fill();
        scrollbarCanvas.ctx.stroke();
      }
    }
  }
}

  /* for overlayOn */
var blockingOverlay=null;
function addBlockingOverlay()
{
  if(!blockingOverlay) blockingOverlay = document.createElement("div");
//  else if(DBG) console.log("error: custom scrollbar already exists");
  blockingOverlay.style.position = "fixed";// absolute";
  blockingOverlay.style.right = "0";
  blockingOverlay.style.top = "0";
  blockingOverlay.style.width = "100%"; // to be checked
  blockingOverlay.style.height = "100%"; // maximum height
  blockingOverlay.style.zIndex = 99998;   //on top of all
  blockingOverlay.style.backgroundColor="#0008";
  //blockingOverlay.style.pointerEvents = 'none';  //does not prevent clicking on whatever is under it
  var blockingOverlayText  = document.createElement("span"); 
  blockingOverlayText.style.position = "absolute";
  blockingOverlayText.style.right = "50%";
  blockingOverlayText.style.top = "45%";
  blockingOverlayText.textContent="Multi Find: found!";
  blockingOverlayText.style.color="black";
  blockingOverlayText.style.backgroundColor="white";
  blockingOverlayText.style.padding = "2px 10px";
  blockingOverlay.appendChild(blockingOverlayText);
  var blockingOverlayButton  = document.createElement("button"); 

  blockingOverlay.appendChild(blockingOverlayButton);
  document.body.appendChild(blockingOverlay);
  blockingOverlayButton.style.backgroundColor="#2A2";
  blockingOverlayButton.style.position = "absolute";// absolute";
  blockingOverlayButton.style.right = "50%";
  blockingOverlayButton.style.top = "50%";
  blockingOverlayButton.textContent = 'permanently disable';
  
  blockingOverlayButton.addEventListener("click",      function()
      {
            chrome.storage.local.get(["display"]).then((result)=>{
                highlightActive=false;
                result.display.highlightActive=highlightActive;
                chrome.storage.local.set({display:result.display}).then(()=>{
                    contentSendMessageToPopup({action:"updateHighlight", highlightActive:highlightActive});
                    updateAllDocHighlightsWhenStabilized();
                    removeBlockingOverlay();
                });
            });            
          //
      });
  
  
  var blockingOverlayButton2 = document.createElement("button"); 
  blockingOverlay.appendChild(blockingOverlayButton2);

  blockingOverlayButton2.style.backgroundColor="#2A2";
  blockingOverlayButton2.style.position = "absolute";// absolute";
  blockingOverlayButton2.style.right = "50%";
  blockingOverlayButton2.style.top = "55%";
  blockingOverlayButton2.textContent = 'temporarily disable';
  
  blockingOverlayButton2.addEventListener("click",      function()
      {
            chrome.storage.local.get(["display"]).then((result)=>{
                highlightActive=false;
                result.display.highlightActive=highlightActive;
                removeBlockingOverlay();
            });            
          //
      });
  blockingOverlayButton2.focus();
 
}
function removeBlockingOverlay()
{
  document.body.removeChild(blockingOverlay);
  blockingOverlay=null;
}

function drawScrollbar() {

//    if (window.getSelection().anchorNode===null) { return;} //iFrame

    //if(DBG) console.log("drawScrollbar");
    
    if(overlayOn && blockingOverlay && !scrollActive) removeBlockingOverlay()
    
    var wordCount=new Array(word.length).fill(0);

    
    // select all span elements with a class that starts with "HL-style-"
    //var spans = document.querySelectorAll(tagName+'[className^="HL-style"]');
    var spans = document.querySelectorAll(tagNameFound);

    scrollbarCanvas.height=scrollbarDiv.clientHeight;
    scrollbarCanvas.ctx.clearRect(0, 0, scrollbarCanvas.width, scrollbarCanvas.height);
    scrollbarCanvas.ctx.fillStyle = "#0001";
    scrollbarCanvas.ctx.strokeStyle = '#0006';
    scrollbarCanvas.ctx.lineWidth = 0.5;
    //if(scrollActive) scrollbarCanvas.ctx.fillRect(0, 0, scrollbarCanvas.width, scrollbarCanvas.height);
    if(spans.length)
    {
      var theme=spans[0].classList.contains("HL-dark-theme") ? 2 : 0;
      
      scrollbarParent.classList.remove(darkTheme[0]);
      scrollbarParent.classList.remove(darkTheme[2]);
      scrollbarParent.classList.add(darkTheme[theme]);
      if(scrollActive) scrollbarButton.style.display="block";  else scrollbarButton.style.display="none";
      scrollbarCanvas.ctx.strokeStyle = theme?'#FFF6':'#0006';
      if(scrollActive) {scrollbarCanvas.ctx.beginPath(); scrollbarCanvas.ctx.moveTo(0, 0); scrollbarCanvas.ctx.lineTo(0, scrollbarCanvas.height); scrollbarCanvas.ctx.stroke();}
    }
    else scrollbarButton.style.display="none";
    
    // iterate over the selected span elements
    for (var i = 0; i < spans.length; i++) {
        drawOneMarker(spans[i], wordCount, i); // this function updates wordCount...
    } 
    var myImage = scrollbarCanvas.toDataURL("image/png");  
    scrollbarDiv.style.backgroundImage = "url("+myImage+")"; 

    selectParam.wordCount=wordCount;
    /*
    if(askedForUpdatePopup) {askedForUpdatePopup=false; contentSendMessageToPopup({action:"updatePopup", from:"content-script.js > drawScrollbar()"})}
    else
    {
      if(isActiveElement) {contentSendMessageToPopup({action:"updateWordCount", wordCount:wordCount, from:"content-script.js > drawScrollbar()"});}
      if(isActiveElement) {
        focusID=Math.floor(Math.random()*9999+1);
        contentSendMessageToBackground({action:"askForFocus", focusID, from:"content-script.js > drawScrollbar()", global:wordCount.reduce(function(a, b){return a + b;}, 0).toString()});
      }
    }
    */
    if(isActiveElement) {
      contentSendMessageToBackground({action:"updateBadge", number:selectParam.wordCount.reduce(function(a, b){return a + b;}, 0).toString()});
      if(askedForUpdatePopup)
        contentSendMessageToPopup({action:"updatePopup", wordCount:selectParam.wordCount, from:"content-script.js > drawScrollbar()"});
      else
        contentSendMessageToPopup({action:"updateWordCount", wordCount:selectParam.wordCount, from:"content-script.js > drawScrollbar()"});
    }
    

    if(overlayOn)
    {
        var found=wordCount.reduce(function(a, b){return a + b;}, 0);
        if(highlightActive && scrollActive && found && !blockingOverlay)
        {
            addBlockingOverlay();
        }
    }
}

function removeOneHighlight(tag, range)
{
    // get the text content of the highlight tag element
    var startContainer1, startOffset1, endContainer1, endOffset1; //was missing! 
    var text = tag.textContent;
    // create a new textNode with the text content
    var textNode = document.createTextNode(text);

    var change0=false;
    var change1=false;
    if(range)
    {
        if(range.startContainer==tag.firstChild)
        {
            startContainer1=textNode;
            startOffset1=range.startOffset;
            if(tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE) startOffset1+=tag.previousSibling.textContent.length;
            change0=true;
        }
        if(range.startContainer==tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE)
        {
            startContainer1=textNode;
            startOffset1=range.startOffset;
            change0=true;
        }
        if(range.startContainer==tag.nextSibling && tag.nextSibling.nodeType === Node.TEXT_NODE)
        {
            startContainer1=textNode;
            startOffset1=range.startOffset;
            if(tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE) startOffset1+=tag.previousSibling.textContent.length;
            startOffset1+=tag.textContent.length;
            change0=true;
        }
        if(range.endContainer==tag.firstChild)
        {
            endContainer1=textNode;
            endOffset1=range.endOffset;
            if(tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE) endOffset1+=tag.previousSibling.textContent.length;
            change1=true;
        }
        if(range.endContainer==tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE)
        {
            endContainer1=textNode;
            endOffset1=range.endOffset;
            change1=true;
        }
        if(range.endContainer==tag.nextSibling && tag.nextSibling.nodeType === Node.TEXT_NODE)
        {
            endContainer1=textNode;
            endOffset1=range.endOffset;
            if(tag.previousSibling && tag.previousSibling.nodeType === Node.TEXT_NODE) endOffset1+=tag.previousSibling.textContent.length;
            endOffset1+=tag.textContent.length;
            change1=true;
        }
    }   
                                
    // replace the highlight tag element with the textNode
    tag.parentNode.replaceChild(textNode, tag);
    //check the two neighbors of the textNode
    if(textNode.previousSibling && textNode.previousSibling.nodeType === Node.TEXT_NODE)
    {
      textNode.textContent=textNode.previousSibling.textContent+textNode.textContent;
      textNode.parentNode.removeChild(textNode.previousSibling);
    }
    if(textNode.nextSibling && textNode.nextSibling.nodeType === Node.TEXT_NODE)
    {
      textNode.textContent=textNode.textContent+textNode.nextSibling.textContent;
      textNode.parentNode.removeChild(textNode.nextSibling);
    }
    
    if(change0 || change1)
    {
      //if(DBG) console.log("1) removeOneHighlight", range);
      if(change0) range.setStart(startContainer1, startOffset1);
      if(change1) range.setEnd(endContainer1, endOffset1);
      //const selection = window.getSelection();
      //selection.removeAllRanges();
      //selection.addRange(range);
      //if(DBG) console.log("2) removeOneHighlight", range);
    }
    return textNode;
}

function removeAllHighlights() {
    //if(DBG) console.log("removeAllHighlights");
    //scrollbarCanvas.width=scrollbarWidth;
    scrollbarCanvas.ctx.clearRect(0, 0, scrollbarCanvas.width, scrollbarCanvas.height);
    var myImage = scrollbarCanvas.toDataURL("image/png");  
    scrollbarDiv.style.backgroundImage = "url("+myImage+")"; //"linear-gradient(to bottom, "+gradientTxt+")";

    var sel= window.getSelection();
    var range = sel.rangeCount? sel.getRangeAt(0):null;
    // select all span elements with a class that starts with "HL-style-"
    //var spans = document.querySelectorAll(tagName+'[className^="HL-style-"]');
    var spans = document.querySelectorAll(tagNameTextareaDummyShort);
    // iterate over the selected span elements
    for (let i = 0; i < spans.length; i++) {
        var child=spans[i].firstChild;
        spans[i].parentNode.replaceChild(child, spans[i]);
    }
    var spans = document.querySelectorAll(tagNameFound);
    // iterate over the selected span elements
    for (let i = 0; i < spans.length; i++) {
        removeOneHighlight(spans[i], range);
    }
    //var spans = document.querySelectorAll(tagName+'[className^="HL-stylenone"]');
    var spans = document.querySelectorAll(tagNameDummy);
    for (let i = 0; i < spans.length; i++) {
        removeOneHighlight(spans[i], range);
    } 
}
