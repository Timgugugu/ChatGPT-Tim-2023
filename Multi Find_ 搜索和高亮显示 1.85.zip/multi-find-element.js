//Multi Find, Vincent Greco, 2023-24
"use strict";

//if(typeof(MultiFind0Extension)==="undefined")
{
  class MultiFind0Extension extends HTMLElement {
    constructor() {
      super();
    }
  }
  customElements.define('multi-find-0-extension', MultiFind0Extension);
}

//if(typeof(MultiFind1Extension)==="undefined")
{
  class MultiFind1Extension extends HTMLElement {
    constructor() {
      super();
    }
  }
  customElements.define('multi-find-1-extension', MultiFind1Extension);
}
