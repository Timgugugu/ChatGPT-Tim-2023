//Multi Find, Vincent Greco, 2023-24
"use strict";

var darkTheme = ['HL-light-theme', 'HL-system-theme', 'HL-dark-theme'];
document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("version").textContent = " "+chrome.i18n.getMessage("wel_version")+" " + chrome.runtime.getManifest().version;

  updateTheme();

  var element = document.querySelectorAll("[data-content-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-content-loc"));
  	element[i].textContent=translation;
  }  
  var element = document.querySelectorAll("[data-title-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-title-loc"));
  	element[i].title=translation;
  }  
  
  var element = document.querySelectorAll("[data-lang-loc]");
  for(var i = 0; i < element.length; i++){
  	var translation = chrome.i18n.getMessage(element[i].getAttribute("data-lang-loc"));
  	element[i].lang=translation;
  }  
  //modify textContent!
  chrome.commands.getAll(function(commands) {
      var element = document.querySelectorAll("[data-shortcut-loc]");
      for(var i = 0; i < element.length; i++){
        const yourActionCommand = commands.find(command => command.name == element[i].getAttribute("data-shortcut-loc"));
        if(yourActionCommand?.shortcut) element[i].textContent=yourActionCommand.shortcut;
        else if(element[i].getAttribute("data-shortcut-loc")==="close") element[i].textContent="Esc";//hardcoded
      }
  });
  
}); 
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    //if(DBG) console.log("action:", message.action);
    if(message.action === "updateOptionsNew") {
        updateTheme();
    }
    if (message.action === "updateHighlightsAndPopup") {  //from background script
        updateTheme();
    }   
    sendResponse({received: "OK"}); 
}); 

function updateTheme()
{
  chrome.storage.local.get(["display"], function(result) {
    var tristateTheme=result?.display?.darkMode;
    setAndReturnActualTheme(tristateTheme);
  });
}

function setAndReturnActualTheme(tristateTheme) // 3 possible values (0=light, 1=system or 2=dark) + undefined
{
    if(tristateTheme===undefined) tristateTheme=1;//default=system
    
    //check system status
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {     
      darkTheme[1]=darkTheme[2]; // browser is in dark mode
    } else {
      darkTheme[1]=darkTheme[0];
    }
    
    //set theme
    document.body.classList.remove(darkTheme[0]);
    document.body.classList.remove(darkTheme[2]);
    document.body.classList.add(darkTheme[tristateTheme]);
    
    //compute actual theme 
    var actualTheme;
    if(tristateTheme==0) actualTheme=0;
    if(tristateTheme==2) actualTheme=1;
    if(tristateTheme==1) actualTheme= darkTheme[1]==darkTheme[2]?1:0;
    
    return actualTheme;
}

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', updateTheme);

