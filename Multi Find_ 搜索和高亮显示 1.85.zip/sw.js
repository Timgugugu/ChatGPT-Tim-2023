//Multi Find, Vincent Greco, 2023-24
"use strict";

var DBG=false;

chrome.runtime.onInstalled.addListener((e) => {
  //if(DBG) console.log("Multi Find> onInstalled.addListener> installed");
  if (e.reason === chrome.runtime.OnInstalledReason.INSTALL) {
    chrome.tabs.create({
      //url: "_locales/"+(chrome.i18n.getMessage("@@ui_locale").split("_")[0])+"/welcome.html"
      url: chrome.i18n.getMessage("fil_welcome")
    });
  }
});

var isIconColor=0;
function checkError(lastError)
{
    if (!lastError) {
      //if(DBG) console.log("Multi Find> onActivated.addListener> response OK.");
      
      if(isIconColor!==2)
      chrome.action.setIcon({
          path: {
            16: "images/icon16.png",
            32: "images/icon32.png"
           },
      });
      isIconColor=2;
      
    } else {
      //if(DBG) console.log("Multi Find> onActivated.addListener> response not OK!");
      
      if(isIconColor!==1)
      chrome.action.setIcon({
          path: {
            16: "images/black16.png",
            32: "images/black32.png"
          },
      });
      isIconColor=1;
      
    }
}

//when the user change tabs inside a same Chrome window
chrome.tabs.onActivated.addListener(function(activeInfo) {
    sendMessageToTab({action:"updateHighlightsAndPopup", from:"sw.js > onActivated", activeInfo});
    return true;
});

//when the user update the URL of the active tab
chrome.tabs.onUpdated.addListener(function(activeInfo) {
//    sendMessageToTab({action:"doHighlight", from:"from SW onUpdated", activeInfo});
    sendMessageToTab({action:"updateHighlightsAndPopup", from:"from SW onUpdated", activeInfo});
    return true;
});


//when the user change Chrome windows
chrome.windows.onFocusChanged.addListener(function(activeInfo) {
    //sendMessageToTab({action:"doHighlight", from:"from SW onFocusChanged", activeInfo});
    return true;
});


chrome.commands.onCommand.addListener((command) => {
  //if(DBG) console.log(`Command "${command}" triggered`);
  //if (command === "toggle_popup")    sendMessageToTab({action:"requestTogglePopup", from:"sw.js > onCommand"});   
  if (command === 'search_next')     sendMessageToTab({action:"doDown", param:-1, from:"sw.js > onCommand"});   
  if (command === 'search_prev')     sendMessageToTab({action:"doUp", param:-1, from:"sw.js > onCommand"}); 
  if (command === 'add_select' )     sendMessageToTab({action:"addSelection"}); 
  if (command === 'toggle_ext')      doToggle("display", "highlightActive"); 
  if (command === 'toggle_glow')     doCycle("display", "style", 3); //2 if you want only to switch from regular to glow
  if (command === 'toggle_case')     doToggle("search",  "maj"); 
  if (command === 'toggle_diac')     doToggle("search",  "diac"); 
  if (command === 'toggle_scroll')   doToggle("display", "scrollActive"); 
});

function doToggle(group, item)
{
    chrome.storage.local.get([group]).then((result)=>{
        result[group][item]=!result[group][item];
        chrome.storage.local.set({[group]:result[group]}).then(()=>{
            sendMessageToAllTabs({action:"updateHighlightsAndPopup", from:"sw.js > onCommand > doToggle()"});
        });
    });            
}

function doCycle(group, item, m)
{
    chrome.storage.local.get([group]).then((result)=>{
        result[group][item]=(result[group][item]+1)%m;
        chrome.storage.local.set({[group]:result[group]}).then(()=>{
            sendMessageToAllTabs({action:"updateHighlightsAndPopup", from:"sw.js > onCommand > doCycle()"});
        });
    });            
}

var persistentMenu=true;

chrome.storage.local.get(["display"], function(result) {
    if(result?.display?.persistentMenu) persistentMenu=result.display.persistentMenu;
});


// Listen for the message event from popup (readFrame) and content-script (writeFrame)
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {

        if(DBG) console.log("received message:",request.action, request);
        /*
        if(request.action=="askForFocus")
        {
          chrome.tabs.query({currentWindow:true, active:true}, function (tabs){
            if (tabs && tabs.length)
            {
                tabs.forEach(tab => {
                    if(DBG) console.log("tab", tab.id, tab.windowId);
                    chrome.webNavigation.getAllFrames({tabId: tab.id}, (frames) => { // where webNavigation is needed
                        frames.forEach((frame) => {
                            if(DBG) console.log("sender.frameId:",sender.frameId,"frame.frameId:",frame.frameId);
                            chrome.tabs.sendMessage(tab.id, {action:"giveFocus", focusID:request.focusID, from:"sw.js > askForFocus", value:sender.frameId===frame.frameId, global:request.global}, {frameId:frame.frameId}, function (response) {
                               //checkError(chrome.runtime.lastError);
                                if (!chrome.runtime.lastError) {
                                } else {
                                }
                            });   
                        });
                    });                    
                    //if(tab.windowId!=sender.tab.windowId) 
                });
            } 
          });
        }
        */
        if(request.action === "askForFocus")   sendMessageToTab({action:"giveFocus", focusID:request.focusID, from:"sw.js > message > askForFocus"/*, global:request.global*/});
        if(request.action === "updateBadge")
        {
            chrome.storage.local.get(["display"], function(result) {
                if(result?.display?.counterOn) updateBadge(sender.tab.id, request.number); else updateBadge(sender.tab.id, "");
            });
        }
        if(request.action === "updateOtherWindows")
        {
            sendMessageToAllTabs({action:"updateHighlightsAndPopup", from:"sw.js > message > updateOtherWindows"});      
        }
        if(request.action === "persistentMenuChange")
        {
            persistentMenu=request.param;
            if(!persistentMenu) sendMessageToEverybodyExcept({action:"requestClosePopup", from:"sw.js > message > persistentMenuChange(off)"}, sender.tab.id);      
        }
        if(request.action === "thereCanBeOnlyOne")
        {
            if(!persistentMenu) sendMessageToEverybodyExcept({action:"requestClosePopup", from:"sw.js > message > thereCanBeOnlyOne"}, sender.tab.id);      
        }
        if(request.action === "transparentMenuChange")
        {
            sendMessageToAllTabs({action:"requestTranparency", value:request.param, from:"sw.js > message > transparentMenuChange()"});      
        }
        return true;
    }
);

chrome.action.onClicked.addListener(tab => {//no more popup window!
    // Send a message to the active tab
    sendMessageToTab({action:"requestTogglePopup", from:"sw.js > onClicked"}); 
  });

function updateBadge(tabId, text)
{
    chrome.action.setBadgeTextColor({ tabId, color:"black"  });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "yellow" });
    chrome.action.setBadgeText({ tabId, text });
}

function sendMessageToTab(message)
{
  if(DBG) 
    console.log("sendMessageToTab(",JSON.stringify(message),")");
  chrome.tabs.query({currentWindow:true, active:true}, function (tabs){
      if (tabs && tabs.length)
      {
        tabs.forEach(tab => {   //there should be only one: the active tab of the active window  (activeTab = tabs[0]);
            chrome.tabs.sendMessage(tab.id, message, function (response) {
                if(DBG) console.log("sw > sendMessageToTab (", message, ")");
                checkError(chrome.runtime.lastError);
            });
        });
      }
  });
}

function sendMessageToAllTabs(message)
{
  if(DBG) 
    console.log("sendMessageToAllTabs(",JSON.stringify(message),")");
  chrome.tabs.query({/*currentWindow:false,*/ active:true}, function (tabs){
      //send to all frames of the active tab
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, message, function (response) {
          if(DBG) console.log("sw > sendMessageToTab (", message, ")");
          if (!chrome.runtime.lastError && response.received=="OK") {
            //if(response.frameId) frameId=response.frameId;
            //if(DBG) console.log("Multi Find> sendMessageToTab>response OK");
          } else {
//            if(DBG) console.log("Multi Find> sendMessageToTab>no response", message, selectedFrame);
          }
        });
      });
  });
}

function sendMessageToEverybodyExcept(message, senderId)
{
  if(DBG) 
    console.log("sendMessageToEvrybody(",JSON.stringify(message),")");
  chrome.tabs.query({/*currentWindow:false, active:true*/}, function (tabs){
      //send to all frames of the active tab
      tabs.forEach(tab => {
        if(tab.id!==senderId) chrome.tabs.sendMessage(tab.id, message, function (response) {
          if(DBG) console.log("sw > sendMessageToTab (", message, ")");
          if (!chrome.runtime.lastError && response.received=="OK") {
            //if(response.frameId) frameId=response.frameId;
            //if(DBG) console.log("Multi Find> sendMessageToTab>response OK");
          } else {
//            if(DBG) console.log("Multi Find> sendMessageToTab>no response", message, selectedFrame);
          }
        });
      });
  });
}
/*
function sendMessageToPopup(message)
{
  if(DBG) 
    console.log("sendMessageToPopup(",JSON.stringify(message),")");
  chrome.runtime.sendMessage(message, {}, function (response) {
    if(DBG) console.log("sw > sendMessageToPopup (", message, ")");
    if (!chrome.runtime.lastError && response.received=="OK") {
      if(DBG) console.log("Multi Find> sendMessageToPopup>response OK");
    } else {
     if(DBG) console.log("Multi Find> sendMessageToPopup>no response", message);
    }
  });
}
*/
chrome.contextMenus.removeAll(function() {
  chrome.commands.getAll(function(commands) {
    const yourActionCommand = commands.find(command => command.name == "add_select");
    var title= chrome.i18n.getMessage("ctx_addselect");
    if(yourActionCommand?.shortcut) title+=" ["+yourActionCommand.shortcut+"]" 
    //NZO!!!
    chrome.contextMenus.create({
      id: "multifindContextMenu",
      title: chrome.i18n.getMessage("ctx_addselect"), //"Add selection to Multi Find",
      contexts: ["selection"],
    });
    
    chrome.contextMenus.create({
      id: "multifindContextMenuSimilar",
      title: chrome.i18n.getMessage("ctx_addsimilar"), // "Add similar words to Multi Find"
      contexts: ["selection"],
    });

    
  });
});

chrome.contextMenus.onClicked.addListener(function(info, tab) {
  if (info.menuItemId === "multifindContextMenu") {
    //if(DBG) console.log("Selected text: " + info.selectionText);
    sendMessageToTab({action:"addSelection", text:info.selectionText}); 
  } else if (info.menuItemId === "multifindContextMenuSimilar") {
    sendMessageToTab({ action: "addSimilarSelection", text: info.selectionText });
  }
});
